# Mobile app
See the main README.md one folder up (sections 4, 5, 6).
