import React, { useState } from 'react';
import { View, Text, Linking } from 'react-native';
import { call, form, errText, oneFile } from '../api';
import { C, Page, Card, Btn, Badge, KV, Icon, CowImage, Loading, ErrorBox, fmt } from '../ui';
import MuzzleCamera from '../components/MuzzleCamera';
import { sendOwnerSms } from '../sms';
import { SCAN_PHOTOS } from '../config/capture';

const detectFn = oneFile('/api/detect'), checkFn = oneFile('/api/check');
const BANNER = { MATCH: ['Cow identified', 'checkmark-circle', C.ok, '#E8F7EE'], POSSIBLE: ['Possible match. Please verify.', 'help-circle', C.amber, C.amberSoft],
  'NEW COW': ['Cow not registered', 'information-circle', C.info, C.infoSoft], RETAKE: ['Photo not usable', 'close-circle', C.danger, C.dangerSoft] };

export default function Scan({ nav, active }) {
  const [stage, setStage] = useState('camera'), [res, setRes] = useState(null);
  const onDone = async (photos) => { setStage('working'); const r = await call('/api/scan', { method: 'POST', body: form({}, photos) }); setRes(r.ok ? r.j : { status: 'ERROR', detail: errText(r) }); setStage('result'); };
  const again = () => { setRes(null); setStage('camera'); };
  const b = res && BANNER[res.status], cow = res?.cow, owner = res?.owner;
  return (
    <Page title="Scan cow" subtitle="Identify a cow by its muzzle">
      {stage === 'camera' && <MuzzleCamera active={active && stage === 'camera'} count={SCAN_PHOTOS} detectFn={detectFn} checkFn={checkFn} onDone={onDone} hint="Aim at the cow's nose pad and tap Start. Photos are taken only when a muzzle is seen." />}
      {stage === 'working' && (<View style={{ alignItems: 'center', paddingTop: 40 }}><Loading /><Text style={{ color: C.sub, marginTop: 14, fontWeight: '600' }}>Identifying the cow…</Text></View>)}
      {stage === 'result' && res && (<>
        {res.status === 'ERROR' ? <ErrorBox text={res.detail} onRetry={again} /> : (<>
          <View style={{ backgroundColor: b[3], borderRadius: 18, padding: 16, flexDirection: 'row', gap: 12, alignItems: 'center', marginBottom: 12 }}>
            <Icon name={b[1]} size={34} color={b[2]} /><View style={{ flex: 1 }}><Text style={{ color: b[2], fontSize: 18, fontWeight: '800' }}>{b[0]}</Text>
              {res.status === 'RETAKE' && <Text style={{ color: C.text }}>{(res.reasons || []).join(', ')}</Text>}{res.status === 'NEW COW' && <Text style={{ color: C.text }}>No registered cow matches this muzzle.</Text>}</View></View>
          {cow && (<Card style={{ padding: 0, overflow: 'hidden' }}><CowImage id={cow.cow_id} has={cow.has_image} size={400} radius={0} style={{ width: '100%', height: 200 }} />
            <View style={{ padding: 16 }}><View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><Text style={{ fontSize: 20, fontWeight: '800', color: C.text }}>{cow.name || cow.cow_id}</Text><Badge text={cow.cow_id} tone="green" icon="paw" /></View>
              <KV icon="paw" k="Breed" v={[cow.breed, cow.sex].filter(Boolean).join(' · ')} /><KV icon="hourglass" k="Age" v={cow.age_text} /><KV icon="color-palette" k="Color" v={cow.color} /><KV icon="location" k="Location" v={cow.location} />
              <KV icon="medkit" k="Registered by" v={cow.registered_by_name ? `Dr. ${cow.registered_by_name.replace(/^dr\.?\s*/i, '')}` : ''} /><KV icon="calendar" k="On" v={fmt(cow.registered_at)} /></View></Card>)}
          {cow && (owner ? (<Card><Text style={{ fontSize: 12, fontWeight: '800', color: C.sub }}>OWNER</Text><Text style={{ fontSize: 18, fontWeight: '800', color: C.text, marginTop: 2 }}>{owner.name}</Text>
            <KV icon="id-card" k="Owner ID" v={owner.owner_id} /><KV icon="call" k="Phone" v={owner.phone} /><KV icon="home" k="Address" v={owner.address} />
            <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}><Btn small icon="call" title="Call" onPress={() => Linking.openURL(`tel:${owner.phone}`)} /><Btn small kind="soft" icon="chatbubble-ellipses" title="SMS" onPress={() => sendOwnerSms({ owner, cowId: cow.cow_id, doctor: nav.user })} /></View></Card>)
            : <Card><Text style={{ color: C.amber, fontWeight: '600' }}>This cow has no owner yet. Open the profile and edit it to add the Owner ID.</Text></Card>)}
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 4 }}>
            {cow && <Btn kind="outline" icon="open" title="Full profile" onPress={() => nav.push('CowDetail', { cow_id: cow.cow_id })} />}
            {res.status === 'NEW COW' && <Btn icon="add-circle" title="Register this cow" onPress={() => nav.tab('register')} />}
            <Btn kind="soft" icon="scan" title="Scan another" onPress={again} /></View></>)}</>)}
    </Page>);
}
