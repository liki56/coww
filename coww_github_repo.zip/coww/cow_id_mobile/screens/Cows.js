import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView } from 'react-native';
import { get, send, call, form, errText } from '../api';
import { C, Page, Card, Btn, Field, SearchBar, Chip, Chips, Segmented, Section, KV, Badge, Icon, CowImage, Empty, Loading, ErrorBox, Msg, confirm, fmt } from '../ui';

export function CowsList({ nav, active }) {
  const [rows, setRows] = useState(null), [q, setQ] = useState(''), [flt, setFlt] = useState('all'), [err, setErr] = useState(''), [ref, setRef] = useState(false);
  const load = async () => { setRef(true); const r = await get(`/api/cows?q=${encodeURIComponent(q)}${flt === 'none' ? '&unowned=true' : ''}`); setRef(false); if (r.ok) { setRows(r.j); setErr(''); } else setErr(errText(r)); };
  useEffect(() => { if (active) load(); }, [active, flt]);
  return (
    <Page title="Cows" subtitle={rows ? `${rows.length} shown` : ''} onRefresh={load} refreshing={ref}>
      <SearchBar value={q} onChangeText={setQ} onSubmitEditing={load} placeholder="Search ID, name, breed, owner…" />
      <Chips><Chip label="All" on={flt === 'all'} onPress={() => setFlt('all')} /><Chip label="No owner" on={flt === 'none'} onPress={() => setFlt('none')} /></Chips>
      {err ? <ErrorBox text={err} onRetry={load} /> : !rows ? <Loading /> : rows.length === 0 ? <Empty title="No cows found" text="Try another search." /> : rows.map((c) => (
        <Card key={c.cow_id} onPress={() => nav.push('CowDetail', { cow_id: c.cow_id })} style={{ flexDirection: 'row', gap: 12, padding: 12 }}>
          <CowImage id={c.cow_id} has={c.has_image} size={72} radius={16} /><View style={{ flex: 1 }}>
            <Text style={{ fontWeight: '800', color: C.text, fontSize: 16 }}>{c.cow_id}{c.name ? `  ·  ${c.name}` : ''}</Text>
            <Text style={{ color: C.sub, marginTop: 2 }}>{[c.breed, c.sex, c.age_text].filter(Boolean).join(' · ') || 'No details'}</Text>
            <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center', marginTop: 6 }}><Icon name="person" size={14} color={C.sub} /><Text style={{ color: c.owner_name ? C.text : C.amber, fontWeight: '600' }}>{c.owner_name || 'No owner'}</Text></View></View></Card>))}
    </Page>);
}

export function CowDetail({ cow_id, nav }) {
  const [c, setC] = useState(null), [err, setErr] = useState(''), [msg, setMsg] = useState(''), admin = nav.user.role === 'ADMIN';
  const load = async () => { const r = await get(`/api/cows/${encodeURIComponent(cow_id)}`); if (r.ok) { setC(r.j); setErr(''); } else setErr(errText(r)); };
  useEffect(() => { load(); }, []);
  const del = () => confirm('Delete cow', 'The cow, its photos and its muzzle data will be erased permanently.', async () => { const r = await send(`/api/cows/${encodeURIComponent(cow_id)}`, 'DELETE'); if (r.ok) nav.pop(); else setMsg(errText(r)); }, 'Delete', true);
  return (
    <Page title="Cow profile" subtitle={cow_id} onBack={nav.pop}>
      {err ? <ErrorBox text={err} onRetry={load} /> : !c ? <Loading /> : (<>
        <Card style={{ padding: 0, overflow: 'hidden' }}><CowImage id={c.cow_id} has={c.has_image} size={400} radius={0} style={{ width: '100%', height: 250 }} />
          <View style={{ padding: 16 }}><View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}><Text style={{ fontSize: 22, fontWeight: '800', color: C.text }}>{c.name || c.cow_id}</Text><Badge text={c.cow_id} tone="green" icon="paw" /></View>
            <Text style={{ color: C.sub, marginTop: 2 }}>{[c.breed, c.sex].filter(Boolean).join(' · ') || ' '}</Text></View></Card>
        <Section title="Details"><Card><KV icon="hourglass" k="Age" v={c.age_text} /><KV icon="color-palette" k="Color" v={c.color} /><KV icon="location" k="Location" v={c.location} /><KV icon="document-text" k="Notes" v={c.notes} />
          <KV icon="finger-print" k="Muzzle photos" v={`${c.n_photos} stored`} /></Card></Section>
        <Section title="Owner">{c.owner ? (<Card onPress={() => nav.push('OwnerDetail', { id: c.owner.owner_id })} style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
          <View style={{ flex: 1 }}><Text style={{ fontWeight: '800', color: C.text, fontSize: 16 }}>{c.owner.name}</Text><Text style={{ color: C.sub }}>{c.owner.phone} · {c.owner.owner_id}</Text></View><Icon name="chevron-forward" color={C.sub} size={18} /></Card>)
          : <Card><Text style={{ color: C.amber, fontWeight: '600' }}>No owner assigned. Tap Edit to add the Owner ID.</Text></Card>}</Section>
        <Section title="Registration"><Card><KV icon="medkit" k="Registered by" v={c.registered_by_name ? `Dr. ${c.registered_by_name.replace(/^dr\.?\s*/i, '')}` : ''} /><KV icon="calendar" k="Date" v={fmt(c.registered_at)} /></Card></Section>
        <Msg text={msg} />
        <View style={{ flexDirection: 'row', gap: 8, marginTop: 6 }}><Btn small icon="create" title="Edit" onPress={() => nav.push('CowEdit', { cow_id })} />{admin && <Btn small kind="danger" icon="trash" title="Delete" onPress={del} />}</View></>)}
    </Page>);
}

export function CowEdit({ cow_id, nav }) {
  const [f, setF] = useState(null), [owner, setOwner] = useState(null), [busy, setBusy] = useState(false), [msg, setMsg] = useState(''), [chk, setChk] = useState('');
  useEffect(() => { get(`/api/cows/${encodeURIComponent(cow_id)}`).then((r) => { if (!r.ok) return setMsg(errText(r)); const c = r.j, m = c.age_now_months ?? 0;
    setF({ name: c.name || '', breed: c.breed || '', sex: c.sex || '', color: c.color || '', location: c.location || '', notes: c.notes || '', age_years: String(Math.floor(m / 12)), age_months: String(m % 12), owner_id: c.owner_id || '' }); setOwner(c.owner); }); }, []);
  const set = (k) => (v) => setF({ ...f, [k]: v });
  const find = async () => { const r = await get(`/api/owners/${f.owner_id.trim().toUpperCase()}`); if (r.ok) { setOwner(r.j); setChk(''); } else { setOwner(null); setChk(errText(r)); } };
  const submit = async () => {
    setBusy(true); setMsg('');
    const r = await call(`/api/cows/${encodeURIComponent(cow_id)}`, { method: 'PUT', body: form({ ...f, age_years: f.age_years || 0, age_months: f.age_months || 0, owner_id: f.owner_id.trim().toUpperCase() }) });
    setBusy(false); if (r.ok) nav.pop(); else setMsg(errText(r));
  };
  return (
    <Page title="Edit cow" subtitle={cow_id} onBack={nav.pop} footer={<Btn title="Save changes" icon="checkmark" onPress={submit} loading={busy} full style={{ flex: 1 }} />}>
      {!f ? (msg ? <ErrorBox text={msg} /> : <Loading />) : (<>
        <Field label="Name" icon="pricetag" value={f.name} onChangeText={set('name')} /><Field label="Breed" icon="paw" value={f.breed} onChangeText={set('breed')} />
        <Text style={{ fontSize: 13, color: C.sub, fontWeight: '700', marginBottom: 6 }}>Sex</Text><Segmented options={[['Female', 'Female'], ['Male', 'Male']]} value={f.sex} onChange={set('sex')} />
        <Field label="Color / markings" icon="color-palette" value={f.color} onChangeText={set('color')} />
        <View style={{ flexDirection: 'row', gap: 12 }}><Field style={{ flex: 1 }} label="Age (years)" value={f.age_years} onChangeText={set('age_years')} keyboardType="number-pad" /><Field style={{ flex: 1 }} label="Months" value={f.age_months} onChangeText={set('age_months')} keyboardType="number-pad" /></View>
        <Field label="Location / shed" icon="location" value={f.location} onChangeText={set('location')} /><Field label="Notes" icon="document-text" value={f.notes} onChangeText={set('notes')} multiline />
        <Field label="Owner ID" icon="id-card" value={f.owner_id} onChangeText={(v) => { setF({ ...f, owner_id: v }); setOwner(null); }} autoCapitalize="characters" placeholder="e.g. OWN0001 (empty = no owner)" error={chk}
          right={<Btn small kind="soft" title="Find" onPress={find} style={{ marginVertical: 0 }} />} />
        {owner && <Card style={{ backgroundColor: C.soft, shadowOpacity: 0 }}><Text style={{ fontWeight: '800', color: C.text }}>{owner.name}</Text><Text style={{ color: C.sub }}>{owner.phone}</Text></Card>}
        <Msg text={msg} /></>)}
    </Page>);
}
