import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { get, errText } from '../api';
import { C, Page, Card, Stat, Grid, Section, Avatar, Icon, CowImage, Empty, Loading, ErrorBox, Badge, fmt, shadow } from '../ui';

const Action = ({ icon, title, sub, onPress, dark }) => (
  <TouchableOpacity onPress={onPress} activeOpacity={0.85} accessibilityRole="button" style={{ flex: 1, backgroundColor: dark ? C.primary : '#fff', borderRadius: 20, padding: 16, ...shadow }}>
    <View style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: dark ? 'rgba(255,255,255,0.2)' : C.soft, alignItems: 'center', justifyContent: 'center' }}><Icon name={icon} size={24} color={dark ? '#fff' : C.primary} /></View>
    <Text style={{ fontSize: 16, fontWeight: '800', color: dark ? '#fff' : C.text, marginTop: 12 }}>{title}</Text><Text style={{ fontSize: 12, color: dark ? '#CBEBDC' : C.sub }}>{sub}</Text></TouchableOpacity>);

export function RecentCows({ rows, nav }) {
  return rows.length === 0 ? <Empty icon="paw" title="No cows yet" text="Registered cows will show up here." /> : rows.map((c) => (
    <Card key={c.cow_id} onPress={() => nav.push('CowDetail', { cow_id: c.cow_id })} style={{ flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12 }}>
      <CowImage id={c.cow_id} has={c.has_image} size={52} />
      <View style={{ flex: 1 }}><Text style={{ fontWeight: '800', color: C.text, fontSize: 15 }}>{c.cow_id}{c.name ? `  ·  ${c.name}` : ''}</Text>
        <Text style={{ color: C.sub, fontSize: 13 }} numberOfLines={1}>{c.owner_name || 'No owner'} · {fmt(c.registered_at)}</Text></View>
      <Icon name="chevron-forward" color={C.sub} size={18} /></Card>));
}

export default function Home({ nav, active }) {
  const [d, setD] = useState(null), [err, setErr] = useState(''), [ref, setRef] = useState(false), admin = nav.user.role === 'ADMIN';
  const load = async () => { setRef(true); const r = await get('/api/dashboard'); setRef(false); if (r.ok) { setD(r.j); setErr(''); } else setErr(errText(r)); };
  useEffect(() => { if (active) load(); }, [active]);
  const h = new Date().getHours(), greet = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  return (
    <Page title={`${greet}`} subtitle={admin ? 'Administrator' : `Dr. ${nav.user.name.replace(/^dr\.?\s*/i, '')}`} onRefresh={load} refreshing={ref}
      right={<TouchableOpacity onPress={() => nav.push('Profile')} accessibilityLabel="Profile"><Avatar name={nav.user.name} bg="rgba(255,255,255,0.22)" fg="#fff" /></TouchableOpacity>}>
      {err ? <ErrorBox text={err} onRetry={load} /> : !d ? <Loading /> : admin ? (<>
        <Grid><Stat icon="medkit" value={d.doctors} label="Doctors" onPress={() => nav.tab('doctors')} /><Stat icon="people" value={d.owners} label="Owners" color={C.info} soft={C.infoSoft} onPress={() => nav.tab('owners')} />
          <Stat icon="paw" value={d.cows} label="Registered cows" onPress={() => nav.tab('cows')} /><Stat icon="today" value={d.today} label="Added today" color={C.amber} soft={C.amberSoft} /></Grid>
        <View style={{ flexDirection: 'row', gap: 12 }}><Action dark icon="person-add" title="Add doctor" sub="Create a login" onPress={() => nav.push('DoctorForm')} /><Action icon="people" title="All owners" sub="With their cows" onPress={() => nav.tab('owners')} /></View>
        {d.no_owner > 0 && <Card style={{ marginTop: 14, backgroundColor: C.amberSoft }} onPress={() => nav.tab('cows')}><View style={{ flexDirection: 'row', gap: 10, alignItems: 'center' }}><Icon name="information-circle" color={C.amber} size={22} />
          <Text style={{ flex: 1, color: C.text }}>{d.no_owner} cow{d.no_owner > 1 ? 's have' : ' has'} no owner yet.</Text></View></Card>}
        <Section title="Recent registrations"><RecentCows rows={d.recent} nav={nav} /></Section></>) : (<>
        <Card style={{ flexDirection: 'row', gap: 12, alignItems: 'center', backgroundColor: C.soft, shadowOpacity: 0 }}><Icon name="location" size={22} color={C.primary} />
          <View style={{ flex: 1 }}><Text style={{ color: C.sub, fontSize: 12, fontWeight: '700' }}>YOUR AREA</Text><Text style={{ color: C.text, fontWeight: '700' }}>{nav.user.area || '-'}</Text></View></Card>
        <View style={{ flexDirection: 'row', gap: 12, marginBottom: 14 }}><Action dark icon="scan" title="Scan cow" sub="Identify by muzzle" onPress={() => nav.tab('scan')} /><Action icon="add-circle" title="Register cow" sub="New cow + owner" onPress={() => nav.tab('register')} /></View>
        <Grid><Stat icon="ribbon" value={d.mine} label="Cows I registered" /><Stat icon="today" value={d.mine_today} label="Registered today" color={C.amber} soft={C.amberSoft} />
          <Stat icon="paw" value={d.cows} label="All cows" onPress={() => nav.tab('cows')} /><Stat icon="people" value={d.owners} label="Owners" color={C.info} soft={C.infoSoft} onPress={() => nav.tab('owners')} /></Grid>
        <Section title="My recent registrations"><RecentCows rows={d.recent} nav={nav} /></Section></>)}
    </Page>);
}
