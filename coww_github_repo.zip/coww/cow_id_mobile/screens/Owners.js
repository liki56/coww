import React, { useEffect, useState } from 'react';
import { View, Text, Linking } from 'react-native';
import { get, send, errText } from '../api';
import { C, Page, Card, Btn, Field, SearchBar, Section, KV, Badge, Avatar, Icon, Empty, Loading, ErrorBox, Msg, confirm, fmt } from '../ui';
import { RecentCows } from './Home';
import { sendOwnerSms } from '../sms';

export function OwnersList({ nav, active }) {
  const [rows, setRows] = useState(null), [q, setQ] = useState(''), [err, setErr] = useState(''), [ref, setRef] = useState(false);
  const load = async () => { setRef(true); const r = await get(`/api/owners?q=${encodeURIComponent(q)}`); setRef(false); if (r.ok) { setRows(r.j); setErr(''); } else setErr(errText(r)); };
  useEffect(() => { if (active) load(); }, [active]);
  return (
    <Page title="Owners" subtitle={rows ? `${rows.length} registered` : ''} onRefresh={load} refreshing={ref}>
      <SearchBar value={q} onChangeText={setQ} onSubmitEditing={load} placeholder="Search name, ID, phone, village…" />
      {err ? <ErrorBox text={err} onRetry={load} /> : !rows ? <Loading /> : rows.length === 0 ? <Empty icon="people" title="No owners yet" text="Owners are created while registering a cow." /> : rows.map((o) => (
        <Card key={o.owner_id} onPress={() => nav.push('OwnerDetail', { id: o.owner_id })} style={{ flexDirection: 'row', gap: 12, alignItems: 'center' }}>
          <Avatar name={o.name} size={50} bg={C.infoSoft} fg={C.info} /><View style={{ flex: 1 }}>
            <Text style={{ fontWeight: '800', color: C.text, fontSize: 16 }}>{o.name}</Text><Text style={{ color: C.sub }}>{o.phone}{o.village ? ` · ${o.village}` : ''}</Text>
            <View style={{ flexDirection: 'row', gap: 6, marginTop: 6 }}><Badge text={o.owner_id} tone="blue" /><Badge text={`${o.n_cows} cow${o.n_cows === 1 ? '' : 's'}`} tone="green" icon="paw" /></View></View>
          <Icon name="chevron-forward" color={C.sub} size={18} /></Card>))}
    </Page>);
}

export function OwnerDetail({ id, nav }) {
  const [o, setO] = useState(null), [err, setErr] = useState(''), [msg, setMsg] = useState(''), admin = nav.user.role === 'ADMIN', doctor = nav.user.role === 'DOCTOR';
  const load = async () => { const r = await get(`/api/owners/${id}`); if (r.ok) { setO(r.j); setErr(''); } else setErr(errText(r)); };
  useEffect(() => { load(); }, []);
  const del = () => confirm('Delete owner', `${o.name} will be removed. Their cows stay registered but become "no owner".`, async () => { const r = await send(`/api/owners/${id}`, 'DELETE'); if (r.ok) nav.pop(); else setMsg(errText(r)); }, 'Delete', true);
  return (
    <Page title="Owner" onBack={nav.pop}>
      {err ? <ErrorBox text={err} onRetry={load} /> : !o ? <Loading /> : (<>
        <Card><View style={{ flexDirection: 'row', gap: 14, alignItems: 'center' }}><Avatar name={o.name} size={64} bg={C.infoSoft} fg={C.info} /><View style={{ flex: 1 }}>
          <Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>{o.name}</Text><View style={{ marginTop: 4 }}><Badge text={`OWNER ID  ${o.owner_id}`} tone="blue" icon="id-card" /></View></View></View>
          <View style={{ height: 8 }} /><KV icon="call" k="Phone" v={o.phone} /><KV icon="home" k="Address" v={o.address} /><KV icon="location" k="Village" v={o.village} /><KV icon="medkit" k="Added by" v={o.created_by_name} /><KV icon="calendar" k="Added on" v={fmt(o.created_at)} /></Card>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
          <Btn small icon="call" title="Call" onPress={() => Linking.openURL(`tel:${o.phone}`)} />
          {doctor && <Btn small kind="soft" icon="chatbubble-ellipses" title="SMS Owner ID" onPress={() => sendOwnerSms({ owner: o, doctor: nav.user })} />}
          <Btn small kind="outline" icon="create" title="Edit" onPress={() => nav.push('OwnerForm', { id })} />{admin && <Btn small kind="danger" icon="trash" title="Delete" onPress={del} />}</View>
        <Msg text={msg} />
        <Section title={`Cows (${o.cows.length})`}><RecentCows rows={o.cows} nav={nav} /></Section></>)}
    </Page>);
}

export function OwnerForm({ id, nav }) {
  const [f, setF] = useState({ name: '', phone: '', address: '', village: '' }), [busy, setBusy] = useState(false), [msg, setMsg] = useState(''), [ready, setReady] = useState(false), [errs, setErrs] = useState({});
  useEffect(() => { get(`/api/owners/${id}`).then((r) => { if (r.ok) setF({ name: r.j.name, phone: r.j.phone, address: r.j.address, village: r.j.village || '' }); setReady(true); }); }, []);
  const set = (k) => (v) => setF({ ...f, [k]: v });
  const submit = async () => {
    const e = {}; if (!f.name.trim()) e.name = 'Enter the name'; if (f.phone.replace(/\D/g, '').length < 10) e.phone = 'Enter a 10-digit phone number'; if (!f.address.trim()) e.address = 'Enter the address';
    setErrs(e); if (Object.keys(e).length) return;
    setBusy(true); const r = await send(`/api/owners/${id}`, 'PUT', f); setBusy(false); if (r.ok) nav.pop(); else setMsg(errText(r));
  };
  return (
    <Page title="Edit owner" subtitle={id} onBack={nav.pop} footer={<Btn title="Save changes" icon="checkmark" onPress={submit} loading={busy} full style={{ flex: 1 }} />}>
      {!ready ? <Loading /> : (<><Field label="Full name *" icon="person" value={f.name} onChangeText={set('name')} error={errs.name} autoCapitalize="words" />
        <Field label="Phone number *" icon="call" value={f.phone} onChangeText={set('phone')} error={errs.phone} keyboardType="phone-pad" />
        <Field label="Address *" icon="home" value={f.address} onChangeText={set('address')} error={errs.address} multiline /><Field label="Village" icon="location" value={f.village} onChangeText={set('village')} /><Msg text={msg} /></>)}
    </Page>);
}
