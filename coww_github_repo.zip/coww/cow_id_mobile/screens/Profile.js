import React, { useState } from 'react';
import { View, Text } from 'react-native';
import { get, send, errText, getBase, saveBase } from '../api';
import { C, Page, Card, Btn, Field, Section, KV, Badge, Avatar, Msg, confirm } from '../ui';

export default function Profile({ nav }) {
  const u = nav.user, [o, setO] = useState(''), [n, setN] = useState(''), [msg, setMsg] = useState(null), [srv, setSrv] = useState(getBase()), [sm, setSm] = useState(null);
  const change = async () => {
    if (n.length < 6) return setMsg({ text: 'New password must be at least 6 characters.' });
    const r = await send('/api/me/password', 'POST', { old_password: o, new_password: n }); setMsg({ ok: r.ok, text: r.ok ? 'Password changed.' : errText(r) }); if (r.ok) { setO(''); setN(''); }
  };
  const saveSrv = async (reset) => { const b = await saveBase(reset ? '' : srv); setSrv(b); const r = await get('/api/health'); setSm({ ok: r.ok, text: r.ok ? `Connected to ${b}` : errText(r) }); };
  return (
    <Page title="Profile" onBack={nav.pop}>
      <Card style={{ alignItems: 'center', paddingVertical: 22 }}><Avatar name={u.name} size={76} /><Text style={{ fontSize: 20, fontWeight: '800', color: C.text, marginTop: 10 }}>{u.name}</Text>
        <Badge text={u.role === 'ADMIN' ? 'ADMINISTRATOR' : 'VETERINARY DOCTOR'} tone="green" />
        <View style={{ alignSelf: 'stretch', marginTop: 14 }}><KV icon="person" k="Login ID" v={u.username} /><KV icon="id-card" k="Doctor ID" v={u.ref_id} /><KV icon="call" k="Phone" v={u.phone} /><KV icon="location" k="Area" v={u.area} /></View></Card>
      <Section title="Change password"><Field label="Current password" icon="lock-closed" value={o} onChangeText={setO} secureTextEntry autoCapitalize="none" /><Field label="New password" icon="key" value={n} onChangeText={setN} secureTextEntry autoCapitalize="none" />
        <Btn small icon="checkmark" title="Change password" onPress={change} /><Msg ok={msg?.ok} text={msg?.text} /></Section>
      <Section title="Server"><Field label="Server address" icon="cloud" value={srv} onChangeText={setSrv} autoCapitalize="none" keyboardType="url" />
        <View style={{ flexDirection: 'row', gap: 8 }}><Btn small kind="outline" title="Save & test" onPress={() => saveSrv(false)} /><Btn small kind="ghost" title="Use default" onPress={() => saveSrv(true)} /></View><Msg ok={sm?.ok} text={sm?.text} /></Section>
      <Btn kind="danger" icon="log-out" title="Sign out" onPress={() => confirm('Sign out', 'Sign out of SmartVet?', nav.logout, 'Sign out')} full style={{ marginTop: 22 }} />
    </Page>);
}
