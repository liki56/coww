import React, { useEffect, useState } from 'react';
import { View, Text, Share } from 'react-native';
import { get, send, errText } from '../api';
import { C, Page, Card, Btn, Field, SearchBar, Section, KV, Badge, Avatar, Icon, Empty, Loading, ErrorBox, Msg, confirm, fmt } from '../ui';
import { RecentCows } from './Home';

export function Creds({ c, onDone }) {
  const text = `SmartVet doctor login\nID: ${c.user_id}\nPassword: ${c.password}`;
  return (<Card style={{ borderLeftWidth: 5, borderLeftColor: C.ok }}>
    <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}><Icon name="key" color={C.ok} size={20} /><Text style={{ fontWeight: '800', color: C.text, fontSize: 16 }}>Login created</Text></View>
    <KV k="Login ID" v={c.user_id} /><KV k="Password" v={c.password} />
    <Text style={{ color: C.amber, fontSize: 12, marginVertical: 8 }}>{c.note}</Text>
    <View style={{ flexDirection: 'row', gap: 8 }}><Btn small icon="share-social" title="Share" onPress={() => Share.share({ message: text })} />{onDone ? <Btn small kind="outline" title="Done" onPress={onDone} /> : null}</View></Card>);
}

export function DoctorsList({ nav, active }) {
  const [rows, setRows] = useState(null), [q, setQ] = useState(''), [err, setErr] = useState(''), [ref, setRef] = useState(false);
  const load = async () => { setRef(true); const r = await get(`/api/doctors?q=${encodeURIComponent(q)}`); setRef(false); if (r.ok) { setRows(r.j); setErr(''); } else setErr(errText(r)); };
  useEffect(() => { if (active) load(); }, [active]);
  return (
    <Page title="Doctors" subtitle={rows ? `${rows.length} total` : ''} onRefresh={load} refreshing={ref}
      right={<Btn small kind="light" icon="add" title="Add" onPress={() => nav.push('DoctorForm')} style={{ marginVertical: 0 }} />}>
      <SearchBar value={q} onChangeText={setQ} onSubmitEditing={load} placeholder="Search name, phone, area…" />
      {err ? <ErrorBox text={err} onRetry={load} /> : !rows ? <Loading /> : rows.length === 0 ? <Empty icon="medkit" title="No doctors yet" text="Tap Add to create the first doctor login." /> : rows.map((d) => (
        <Card key={d.doctor_id} onPress={() => nav.push('DoctorDetail', { id: d.doctor_id })} style={{ flexDirection: 'row', gap: 12 }}>
          <Avatar name={d.name} size={50} /><View style={{ flex: 1 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}><Text style={{ fontWeight: '800', color: C.text, fontSize: 16 }}>Dr. {d.name.replace(/^dr\.?\s*/i, '')}</Text>{!d.active && <Badge text="INACTIVE" tone="red" />}</View>
            <Text style={{ color: C.sub, marginTop: 2 }}>{d.doctor_id} · {d.phone}</Text>
            <View style={{ flexDirection: 'row', gap: 6, marginTop: 4 }}><Icon name="location" size={14} color={C.primary} /><Text style={{ color: C.sub, flex: 1 }} numberOfLines={2}>{d.area}</Text></View>
            <View style={{ marginTop: 8 }}><Badge text={`${d.cows_registered} cows registered`} tone="green" icon="paw" /></View></View></Card>))}
    </Page>);
}

export function DoctorDetail({ id, nav }) {
  const [d, setD] = useState(null), [err, setErr] = useState(''), [cred, setCred] = useState(null), [msg, setMsg] = useState('');
  const load = async () => { const r = await get(`/api/doctors/${id}`); if (r.ok) { setD(r.j); setErr(''); } else setErr(errText(r)); };
  useEffect(() => { load(); }, []);
  const run = async (fn, after) => { const r = await fn(); if (!r.ok) return setMsg(errText(r)); setMsg(''); after ? after(r) : load(); };
  const reset = () => confirm('Reset password', `Create a new temporary password for ${d.name}?`, () => run(() => send(`/api/doctors/${id}/reset-password`, 'POST'), (r) => setCred(r.j.credentials)), 'Reset');
  const toggle = () => confirm(d.active ? 'Deactivate doctor' : 'Activate doctor', d.active ? `${d.name} will no longer be able to sign in. Their registered cows are kept.` : `Allow ${d.name} to sign in again?`,
    () => run(() => d.active ? send(`/api/doctors/${id}`, 'DELETE') : send(`/api/doctors/${id}/activate`, 'POST')), d.active ? 'Deactivate' : 'Activate', d.active);
  const del = () => confirm('Delete permanently', 'This removes the doctor and login. Only possible when no cows were registered by this doctor.', () => run(() => send(`/api/doctors/${id}?permanent=true`, 'DELETE'), nav.pop), 'Delete', true);
  return (
    <Page title="Doctor" onBack={nav.pop}>
      {err ? <ErrorBox text={err} onRetry={load} /> : !d ? <Loading /> : (<>
        <Card><View style={{ flexDirection: 'row', gap: 14, alignItems: 'center' }}><Avatar name={d.name} size={64} /><View style={{ flex: 1 }}>
          <Text style={{ fontSize: 19, fontWeight: '800', color: C.text }}>Dr. {d.name.replace(/^dr\.?\s*/i, '')}</Text><Badge text={d.active ? 'ACTIVE' : 'INACTIVE'} tone={d.active ? 'green' : 'red'} /></View></View>
          <View style={{ height: 8 }} /><KV icon="id-card" k="Doctor ID" v={d.doctor_id} /><KV icon="person" k="Login ID" v={d.username} /><KV icon="call" k="Phone" v={d.phone} /><KV icon="calendar" k="Added" v={fmt(d.created_at)} /></Card>
        <Section title="Assigned area / villages"><Card><View style={{ flexDirection: 'row', gap: 10 }}><Icon name="location" color={C.primary} size={20} /><Text style={{ flex: 1, color: C.text, lineHeight: 21 }}>{d.area}</Text></View></Card></Section>
        {cred && <Creds c={cred} onDone={() => setCred(null)} />}<Msg text={msg} />
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}><Btn small icon="create" title="Edit" onPress={() => nav.push('DoctorForm', { id })} /><Btn small kind="outline" icon="key" title="Reset password" onPress={reset} />
          <Btn small kind="outline" icon={d.active ? 'pause-circle' : 'play-circle'} title={d.active ? 'Deactivate' : 'Activate'} onPress={toggle} /><Btn small kind="danger" icon="trash" title="Delete" onPress={del} /></View>
        <Section title={`Cows registered (${d.cows_registered})`}><RecentCows rows={d.cows} nav={nav} /></Section></>)}
    </Page>);
}

export function DoctorForm({ id, nav }) {
  const [f, setF] = useState({ name: '', phone: '', area: '', username: '', password: '' }), [busy, setBusy] = useState(false), [msg, setMsg] = useState(''), [cred, setCred] = useState(null), [ready, setReady] = useState(!id), [errs, setErrs] = useState({});
  useEffect(() => { if (id) get(`/api/doctors/${id}`).then((r) => { if (r.ok) setF({ ...f, name: r.j.name, phone: r.j.phone, area: r.j.area }); setReady(true); }); }, []);
  const set = (k) => (v) => setF({ ...f, [k]: v });
  const submit = async () => {
    const e = {}; if (!f.name.trim()) e.name = 'Enter the doctor\'s name'; if (!/^\d{10}$/.test(f.phone.replace(/\D/g, '').slice(-10)) || f.phone.replace(/\D/g, '').length < 10) e.phone = 'Enter a 10-digit phone number';
    if (!f.area.trim()) e.area = 'Enter the villages / areas'; if (!id && f.password && f.password.length < 6) e.password = 'At least 6 characters';
    setErrs(e); if (Object.keys(e).length) return;
    setBusy(true); setMsg('');
    const body = { name: f.name, phone: f.phone, area: f.area }; if (!id) { body.username = f.username; body.password = f.password; }
    const r = id ? await send(`/api/doctors/${id}`, 'PUT', body) : await send('/api/doctors', 'POST', body);
    setBusy(false); if (!r.ok) return setMsg(errText(r)); if (id) nav.pop(); else setCred(r.j.credentials);
  };
  return (
    <Page title={id ? 'Edit doctor' : 'New doctor'} onBack={nav.pop} footer={cred ? null : <Btn title={id ? 'Save changes' : 'Create doctor'} icon="checkmark" onPress={submit} loading={busy} full style={{ flex: 1 }} />}>
      {cred ? (<><Creds c={cred} /><Btn title="Done" onPress={nav.pop} full /></>) : !ready ? <Loading /> : (<>
        <Field label="Full name *" icon="person" value={f.name} onChangeText={set('name')} error={errs.name} autoCapitalize="words" />
        <Field label="Phone number *" icon="call" value={f.phone} onChangeText={set('phone')} error={errs.phone} keyboardType="phone-pad" placeholder="10-digit mobile" />
        <Field label="Assigned villages / areas *" icon="location" value={f.area} onChangeText={set('area')} error={errs.area} multiline placeholder="e.g. Srinivaspura, Yeldur, Mulbagal" />
        {!id && (<Section title="Login (optional)"><Text style={{ color: C.sub, marginBottom: 10 }}>Leave empty to generate them automatically.</Text>
          <Field label="Login ID" icon="at" value={f.username} onChangeText={set('username')} autoCapitalize="none" />
          <Field label="Password" icon="lock-closed" value={f.password} onChangeText={set('password')} error={errs.password} autoCapitalize="none" /></Section>)}
        <Msg text={msg} /></>)}
    </Page>);
}
