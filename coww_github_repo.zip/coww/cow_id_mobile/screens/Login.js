import React, { useState } from 'react';
import { View, Text, KeyboardAvoidingView, Platform, ScrollView, TouchableOpacity } from 'react-native';
import { send, get, getBase, saveBase, errText } from '../api';
import { C, Btn, Field, Msg, Icon, Card, shadow } from '../ui';

export default function Login({ onLogin }) {
  const [login, setLogin] = useState(''), [pw, setPw] = useState(''), [show, setShow] = useState(false), [busy, setBusy] = useState(false), [msg, setMsg] = useState('');
  const [srvOpen, setSrvOpen] = useState(!getBase()), [srv, setSrv] = useState(getBase()), [sm, setSm] = useState(null);
  const go = async () => {
    if (!login.trim() || !pw) return setMsg('Enter your ID and password.');
    setBusy(true); setMsg('');
    const r = await send('/api/auth/login', 'POST', { login: login.trim(), password: pw });
    setBusy(false);
    if (r.ok) onLogin(r.j.token, r.j.user); else setMsg(errText(r));
  };
  const saveSrv = async (reset) => { const u = await saveBase(reset ? '' : srv); setSrv(u); const r = await get('/api/health'); setSm({ ok: r.ok, text: r.ok ? `Connected to ${u}` : u ? errText(r) : 'No server address set.' }); };
  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: C.primary }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps="handled">
        <View style={{ alignItems: 'center', paddingTop: 80, paddingBottom: 46 }}>
          <View style={{ width: 92, height: 92, borderRadius: 30, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', ...shadow }}><Icon name="paw" size={48} color={C.primary} /></View>
          <Text style={{ color: '#fff', fontSize: 32, fontWeight: '800', marginTop: 16 }}>SmartVet</Text>
          <Text style={{ color: '#BFE5D2', fontSize: 14, marginTop: 4 }}>Cow identification for veterinary care</Text>
        </View>
        <View style={{ flex: 1, backgroundColor: C.bg, borderTopLeftRadius: 32, borderTopRightRadius: 32, padding: 24, paddingBottom: 40 }}>
          <Text style={{ fontSize: 22, fontWeight: '800', color: C.text }}>Welcome back</Text>
          <Text style={{ color: C.sub, marginBottom: 20, marginTop: 2 }}>Sign in with the ID and password from your admin.</Text>
          <Field label="ID" icon="person" value={login} onChangeText={setLogin} autoCapitalize="none" autoCorrect={false} placeholder="Your login ID" />
          <Field label="Password" icon="lock-closed" value={pw} onChangeText={setPw} secureTextEntry={!show} autoCapitalize="none" placeholder="Your password" onSubmitEditing={go}
            right={<TouchableOpacity onPress={() => setShow(!show)} accessibilityLabel="Show password"><Icon name={show ? 'eye-off' : 'eye'} color={C.sub} /></TouchableOpacity>} />
          <Btn title="Sign in" icon="log-in" onPress={go} loading={busy} full />
          <Msg text={msg} />
          <TouchableOpacity onPress={() => setSrvOpen(!srvOpen)} style={{ marginTop: 26, alignSelf: 'center', flexDirection: 'row', gap: 6, alignItems: 'center' }}>
            <Icon name="settings-outline" size={16} color={C.sub} /><Text style={{ color: C.sub, fontWeight: '600' }}>{srvOpen ? 'Hide server settings' : 'Server settings'}</Text></TouchableOpacity>
          {srvOpen && (<Card style={{ marginTop: 12 }}>
            <Field label="Server address" icon="cloud" value={srv} onChangeText={setSrv} autoCapitalize="none" autoCorrect={false} keyboardType="url" placeholder="https://api.yourdomain.com" />
            <View style={{ flexDirection: 'row', gap: 8 }}><Btn small title="Save & test" onPress={() => saveSrv(false)} /><Btn small kind="outline" title="Use default" onPress={() => saveSrv(true)} /></View>
            <Msg ok={sm?.ok} text={sm?.text} /></Card>)}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>);
}
