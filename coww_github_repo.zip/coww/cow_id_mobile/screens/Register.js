import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, Alert } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { get, call, form, errText, oneFile } from '../api';
import { C, Page, Card, Btn, Field, Segmented, Section, KV, Badge, Icon, Msg, shadow } from '../ui';
import MuzzleCamera from '../components/MuzzleCamera';
import { sendOwnerSms } from '../sms';
import { REGISTER_PHOTOS } from '../config/capture';

const STEPS = ['Owner', 'Cow', 'Muzzle', 'Photo', 'Review'];
const EMPTY = { mode: 'id', owner_id: '', owner: null, n_name: '', n_phone: '', n_address: '', n_village: '', cow_id: '', name: '', breed: '', sex: '', color: '',
  age_years: '', age_months: '', location: '', notes: '', photos: [], full: null };
const detectFn = oneFile('/api/detect'), checkFn = oneFile('/api/check');

function Progress({ step }) {
  return (<View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 18 }}>
    {STEPS.map((l, i) => (<React.Fragment key={l}>
      <View style={{ alignItems: 'center', width: 52 }}>
        <View style={{ width: 30, height: 30, borderRadius: 15, backgroundColor: i <= step ? C.primary : '#DCE5DF', alignItems: 'center', justifyContent: 'center' }}>
          {i < step ? <Icon name="checkmark" size={16} color="#fff" /> : <Text style={{ color: i <= step ? '#fff' : C.sub, fontWeight: '800', fontSize: 13 }}>{i + 1}</Text>}</View>
        <Text style={{ fontSize: 11, marginTop: 4, color: i <= step ? C.primary : C.sub, fontWeight: '700' }}>{l}</Text></View>
      {i < STEPS.length - 1 && <View style={{ flex: 1, height: 3, backgroundColor: i < step ? C.primary : '#DCE5DF', marginBottom: 16 }} />}</React.Fragment>))}</View>);
}

export default function Register({ nav, active }) {
  const [step, setStep] = useState(0), [d, setD] = useState(EMPTY), [errs, setErrs] = useState({}), [busy, setBusy] = useState(false), [msg, setMsg] = useState(''), [dup, setDup] = useState(false), [done, setDone] = useState(null), [chk, setChk] = useState('');
  const set = (k) => (v) => setD((p) => ({ ...p, [k]: v }));
  const reset = () => { setD(EMPTY); setStep(0); setErrs({}); setMsg(''); setDup(false); setDone(null); };

  const findOwner = async () => {
    const id = d.owner_id.trim().toUpperCase(); if (!id) return setChk('Enter the Owner ID.');
    const r = await get(`/api/owners/${id}`); if (r.ok) { setD((p) => ({ ...p, owner: r.j, owner_id: id })); setChk(''); } else { setD((p) => ({ ...p, owner: null })); setChk(errText(r)); }
  };
  const validate = () => {
    const e = {};
    if (step === 0) {
      if (d.mode === 'id' && !d.owner) e.owner_id = 'Enter the Owner ID and tap Find, or choose "New owner".';
      if (d.mode === 'new') { if (!d.n_name.trim()) e.n_name = 'Enter the owner\'s name'; if (d.n_phone.replace(/\D/g, '').length < 10) e.n_phone = 'Enter a 10-digit phone number'; if (!d.n_address.trim()) e.n_address = 'Enter the address'; }
    }
    if (step === 1 && d.age_years === '' && d.age_months === '') e.age = 'Enter the cow\'s age (years and/or months)';
    if (step === 1 && Number(d.age_months || 0) > 11) e.age = 'Months must be 0 to 11';
    if (step === 2 && d.photos.length < REGISTER_PHOTOS) e.photos = 'Capture the muzzle photos first.';
    if (step === 3 && !d.full) e.full = 'Add the full cow photo.';
    setErrs(e); return !Object.keys(e).length;
  };
  const next = () => { if (validate()) setStep(step + 1); };

  const pickFull = async (from) => {
    let r;
    if (from === 'camera') { const p = await ImagePicker.requestCameraPermissionsAsync(); if (!p.granted) return Alert.alert('Camera permission is needed.'); r = await ImagePicker.launchCameraAsync({ quality: 0.7 }); }
    else r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.7 });
    if (!r.canceled) { set('full')(r.assets[0]); setErrs({}); }
  };

  const submit = async (force) => {
    setBusy(true); setMsg(''); setDup(false);
    const f = { cow_id: d.cow_id.trim(), name: d.name, breed: d.breed, sex: d.sex, color: d.color, age_years: d.age_years || 0, age_months: d.age_months || 0, location: d.location, notes: d.notes, force: !!force };
    if (d.mode === 'id') f.owner_id = d.owner.owner_id;
    if (d.mode === 'new') Object.assign(f, { new_owner_name: d.n_name, new_owner_phone: d.n_phone, new_owner_address: d.n_address, new_owner_village: d.n_village });
    const r = await call('/api/cows', { method: 'POST', body: form(f, d.photos, { full_image: d.full }) });
    setBusy(false);
    if (r.ok) { setDone(r.j); if (r.j.owner_created) setTimeout(() => sendOwnerSms({ owner: r.j.owner, cowId: r.j.cow_id, doctor: nav.user }), 700); return; }
    let t = r.j.message || errText(r); const rej = r.j.rejected && Object.entries(r.j.rejected);
    if (rej?.length) t += '\nRejected photos: ' + rej.map(([i, w]) => `#${i} (${w.join(', ')})`).join('; ');
    setMsg(t); setDup(!!r.j.duplicate);
  };

  if (done) return (
    <Page title="Registered" subtitle={done.cow_id}>
      <View style={{ alignItems: 'center', paddingVertical: 18 }}><View style={{ width: 88, height: 88, borderRadius: 44, backgroundColor: '#E8F7EE', alignItems: 'center', justifyContent: 'center' }}><Icon name="checkmark-circle" size={60} color={C.ok} /></View>
        <Text style={{ fontSize: 22, fontWeight: '800', color: C.text, marginTop: 12 }}>Cow registered</Text><Text style={{ color: C.sub }}>Cow ID {done.cow_id}</Text></View>
      {done.owner && (<Card><Text style={{ color: C.sub, fontSize: 12, fontWeight: '800' }}>OWNER</Text><Text style={{ fontSize: 18, fontWeight: '800', color: C.text, marginTop: 2 }}>{done.owner.name}</Text>
        <View style={{ flexDirection: 'row', gap: 8, marginVertical: 8 }}><Badge text={`OWNER ID  ${done.owner.owner_id}`} tone="blue" icon="id-card" />{done.owner_created && <Badge text="NEW" tone="green" />}</View>
        <Text style={{ color: C.sub }}>{done.owner.phone}</Text>
        <Btn icon="chatbubble-ellipses" title={done.owner_created ? 'Send Owner ID by SMS' : 'Send SMS to owner'} onPress={() => sendOwnerSms({ owner: done.owner, cowId: done.cow_id, doctor: nav.user })} full style={{ marginTop: 12 }} />
        <Text style={{ color: C.sub, fontSize: 12, marginTop: 6 }}>Opens your phone's SMS app with the message ready. It is sent from your number, with your number for emergencies.</Text></Card>)}
      <Btn kind="outline" icon="paw" title="View cow" onPress={() => nav.push('CowDetail', { cow_id: done.cow_id })} full /><Btn kind="soft" icon="add-circle" title="Register another cow" onPress={reset} full />
    </Page>);

  const Review = () => (<>
    <Card><Text style={{ fontSize: 12, fontWeight: '800', color: C.sub }}>OWNER</Text>
      {d.mode === 'id' && <><KV k="Name" v={d.owner?.name} /><KV k="Owner ID" v={d.owner?.owner_id} /><KV k="Phone" v={d.owner?.phone} /></>}
      {d.mode === 'new' && <><KV k="Name" v={d.n_name} /><KV k="Phone" v={d.n_phone} /><KV k="Address" v={d.n_address} /><KV k="Village" v={d.n_village} /><Badge text="NEW OWNER ID WILL BE CREATED" tone="blue" /></>}
      {d.mode === 'none' && <Text style={{ color: C.sub, marginTop: 6 }}>No owner (can be added later)</Text>}</Card>
    <Card><Text style={{ fontSize: 12, fontWeight: '800', color: C.sub }}>COW</Text><KV k="Cow ID" v={d.cow_id || 'Automatic'} /><KV k="Name" v={d.name} /><KV k="Breed" v={d.breed} /><KV k="Sex" v={d.sex} /><KV k="Color" v={d.color} />
      <KV k="Age" v={`${d.age_years || 0} yr ${d.age_months || 0} mo`} /><KV k="Location" v={d.location} /><KV k="Notes" v={d.notes} /></Card>
    <View style={{ flexDirection: 'row', gap: 12 }}>{d.full && <Image source={{ uri: d.full.uri }} style={{ width: 110, height: 110, borderRadius: 16 }} />}
      <View style={{ flex: 1, justifyContent: 'center' }}><Badge text={`${d.photos.length} muzzle photos`} tone="green" icon="finger-print" /><Text style={{ color: C.sub, marginTop: 6 }}>Muzzle + full photo ready.</Text></View></View>
    <Msg text={msg} />{dup && <Btn kind="outline" title="Register anyway" onPress={() => submit(true)} style={{ marginTop: 8 }} />}</>);

  return (
    <Page title="Register cow" subtitle={`Step ${step + 1} of ${STEPS.length}`}
      footer={<>{step > 0 && <Btn kind="outline" icon="arrow-back" title="Back" onPress={() => { setErrs({}); setStep(step - 1); }} />}
        {step < 4 ? <Btn title="Next" icon="arrow-forward" onPress={next} style={{ flex: 1 }} full /> : <Btn title="Register cow" icon="checkmark-circle" onPress={() => submit(false)} loading={busy} style={{ flex: 1 }} full />}</>}>
      <Progress step={step} />
      {step === 0 && (<>
        <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>Who owns this cow?</Text><Text style={{ color: C.sub, marginBottom: 14 }}>Enter the Owner ID, or create the owner now.</Text>
        <Segmented options={[['id', 'Owner ID'], ['new', 'New owner'], ['none', 'Skip']]} value={d.mode} onChange={(m) => { set('mode')(m); setErrs({}); }} />
        {d.mode === 'id' && (<><Field label="Owner ID" icon="id-card" value={d.owner_id} onChangeText={(v) => setD((p) => ({ ...p, owner_id: v, owner: null }))} autoCapitalize="characters" placeholder="e.g. OWN0001" error={errs.owner_id || chk}
          right={<Btn small kind="soft" title="Find" onPress={findOwner} style={{ marginVertical: 0 }} />} />
          {d.owner && <Card style={{ backgroundColor: C.soft, shadowOpacity: 0 }}><View style={{ flexDirection: 'row', gap: 10, alignItems: 'center' }}><Icon name="checkmark-circle" color={C.ok} size={24} /><View><Text style={{ fontWeight: '800', color: C.text }}>{d.owner.name}</Text><Text style={{ color: C.sub }}>{d.owner.phone} · {d.owner.village || d.owner.address}</Text></View></View></Card>}</>)}
        {d.mode === 'new' && (<><Field label="Owner name *" icon="person" value={d.n_name} onChangeText={set('n_name')} error={errs.n_name} autoCapitalize="words" />
          <Field label="Phone number *" icon="call" value={d.n_phone} onChangeText={set('n_phone')} error={errs.n_phone} keyboardType="phone-pad" placeholder="10-digit mobile" />
          <Field label="Address *" icon="home" value={d.n_address} onChangeText={set('n_address')} error={errs.n_address} multiline /><Field label="Village" icon="location" value={d.n_village} onChangeText={set('n_village')} />
          <Card style={{ backgroundColor: C.infoSoft, shadowOpacity: 0 }}><Text style={{ color: C.text }}>An Owner ID is created automatically. After registering, your SMS app opens with the ID ready to send to this number.</Text></Card></>)}
        {d.mode === 'none' && <Card style={{ backgroundColor: C.amberSoft, shadowOpacity: 0 }}><Text style={{ color: C.text }}>The cow will be registered without an owner. You can add the Owner ID later by editing the cow.</Text></Card>}</>)}
      {step === 1 && (<>
        <Text style={{ fontSize: 18, fontWeight: '800', color: C.text, marginBottom: 14 }}>Cow details</Text>
        <Field label="Cow ID / tag number" icon="pricetag" value={d.cow_id} onChangeText={set('cow_id')} autoCapitalize="characters" placeholder="Leave empty to generate (COW0001…)" />
        <Field label="Name" icon="heart" value={d.name} onChangeText={set('name')} /><Field label="Breed" icon="paw" value={d.breed} onChangeText={set('breed')} placeholder="e.g. Gir, HF, Jersey" />
        <Text style={{ fontSize: 13, color: C.sub, fontWeight: '700', marginBottom: 6 }}>Sex</Text><Segmented options={[['Female', 'Female'], ['Male', 'Male']]} value={d.sex} onChange={set('sex')} />
        <Field label="Color / markings" icon="color-palette" value={d.color} onChangeText={set('color')} />
        <View style={{ flexDirection: 'row', gap: 12 }}><Field style={{ flex: 1 }} label="Age: years *" value={d.age_years} onChangeText={set('age_years')} keyboardType="number-pad" placeholder="0" error={errs.age ? ' ' : ''} />
          <Field style={{ flex: 1 }} label="Months" value={d.age_months} onChangeText={set('age_months')} keyboardType="number-pad" placeholder="0" /></View>
        {errs.age ? <Text style={{ color: C.danger, marginTop: -8, marginBottom: 10 }}>{errs.age}</Text> : null}
        <Field label="Location / shed" icon="location" value={d.location} onChangeText={set('location')} /><Field label="Notes" icon="document-text" value={d.notes} onChangeText={set('notes')} multiline /></>)}
      {step === 2 && (<>
        <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>Muzzle photos</Text><Text style={{ color: C.sub, marginBottom: 14 }}>The camera only takes a photo when it sees the cow's muzzle. {REGISTER_PHOTOS} photos are needed.</Text>
        {d.photos.length < REGISTER_PHOTOS ? <MuzzleCamera active={active && step === 2} count={REGISTER_PHOTOS} detectFn={detectFn} checkFn={checkFn} onDone={(p) => { set('photos')(p); setErrs({}); }} />
          : (<><View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>{d.photos.map((p, i) => <Image key={i} source={{ uri: p.uri }} style={{ width: 90, height: 90, borderRadius: 14 }} />)}</View>
            <Msg ok text={`${d.photos.length} muzzle photos captured.`} /><Btn kind="outline" icon="refresh" title="Retake muzzle photos" onPress={() => set('photos')([])} style={{ marginTop: 8 }} /></>)}
        {errs.photos ? <Text style={{ color: C.danger, marginTop: 8 }}>{errs.photos}</Text> : null}</>)}
      {step === 3 && (<>
        <Text style={{ fontSize: 18, fontWeight: '800', color: C.text }}>Full cow photo</Text><Text style={{ color: C.sub, marginBottom: 14 }}>Take one clear photo of the whole cow, side view.</Text>
        {d.full ? <Image source={{ uri: d.full.uri }} style={{ width: '100%', height: 260, borderRadius: 20, marginBottom: 12 }} /> :
          <View style={{ height: 200, borderRadius: 20, backgroundColor: '#E6ECE8', alignItems: 'center', justifyContent: 'center', marginBottom: 12 }}><Icon name="image" size={46} color={C.sub} /><Text style={{ color: C.sub, marginTop: 6 }}>No photo yet</Text></View>}
        <View style={{ flexDirection: 'row', gap: 8 }}><Btn icon="camera" title={d.full ? 'Retake' : 'Take photo'} onPress={() => pickFull('camera')} /><Btn kind="outline" icon="images" title="Gallery" onPress={() => pickFull('gallery')} /></View>
        {errs.full ? <Text style={{ color: C.danger, marginTop: 8 }}>{errs.full}</Text> : null}</>)}
      {step === 4 && (<><Text style={{ fontSize: 18, fontWeight: '800', color: C.text, marginBottom: 12 }}>Review & register</Text><Review /></>)}
    </Page>);
}
