import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, BackHandler, ActivityIndicator } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { get, setToken, onUnauthorized, loadBase } from './api';
import { C, Icon, shadow } from './ui';
import Login from './screens/Login';
import Home from './screens/Home';
import { DoctorsList, DoctorDetail, DoctorForm } from './screens/Doctors';
import { OwnersList, OwnerDetail, OwnerForm } from './screens/Owners';
import { CowsList, CowDetail, CowEdit } from './screens/Cows';
import Register from './screens/Register';
import Scan from './screens/Scan';
import Profile from './screens/Profile';

// Two roles only. [key, icon, label, big?]
const TABS = {
  ADMIN: [['home', 'home', 'Home'], ['doctors', 'medkit', 'Doctors'], ['owners', 'people', 'Owners'], ['cows', 'paw', 'Cows']],
  DOCTOR: [['home', 'home', 'Home'], ['scan', 'scan', 'Scan'], ['register', 'add', 'Register', true], ['cows', 'paw', 'Cows'], ['owners', 'people', 'Owners']],
};
const SCREENS = { DoctorDetail, DoctorForm, OwnerDetail, OwnerForm, CowDetail, CowEdit, Profile };

export default function App() {
  const [boot, setBoot] = useState(true), [user, setUser] = useState(null), [tab, setTab] = useState('home'), [stack, setStack] = useState([]);
  const logout = useCallback(async () => { setToken(null); await AsyncStorage.removeItem('token'); setUser(null); setStack([]); setTab('home'); }, []);
  const signedIn = (tok, u) => { setToken(tok); AsyncStorage.setItem('token', tok); setUser(u); setStack([]); setTab('home'); };
  useEffect(() => {
    onUnauthorized(logout);
    (async () => {
      await loadBase(); const tok = await AsyncStorage.getItem('token');
      if (tok) { setToken(tok); const r = await get('/api/me'); if (r.ok) setUser(r.j); else if (r.status === 401) { setToken(null); await AsyncStorage.removeItem('token'); } }
      setBoot(false);
    })();
  }, []);
  useEffect(() => {
    const h = BackHandler.addEventListener('hardwareBackPress', () => { if (stack.length) { setStack((s) => s.slice(0, -1)); return true; } if (tab !== 'home' && user) { setTab('home'); return true; } return false; });
    return () => h.remove();
  }, [stack.length, tab, user]);

  if (boot) return <View style={{ flex: 1, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center' }}><Icon name="paw" size={56} color="#fff" /><ActivityIndicator color="#fff" style={{ marginTop: 20 }} /></View>;
  if (!user) return (<><StatusBar style="light" /><Login onLogin={signedIn} /></>);

  const nav = { user, logout, push: (name, params = {}) => setStack((s) => [...s, { name, params }]), pop: () => setStack((s) => s.slice(0, -1)), tab: (t) => { setStack([]); setTab(t); } };
  const top = stack[stack.length - 1], Top = top && SCREENS[top.name], showing = !top, tabs = TABS[user.role];
  const has = (k) => tabs.some((t) => t[0] === k), on = (k) => showing && tab === k;
  const vis = (k) => ({ flex: 1, display: on(k) ? 'flex' : 'none' });
  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <StatusBar style="light" />
      <View style={vis('home')}><Home nav={nav} active={on('home')} /></View>
      {has('doctors') && <View style={vis('doctors')}><DoctorsList nav={nav} active={on('doctors')} /></View>}
      {has('owners') && <View style={vis('owners')}><OwnersList nav={nav} active={on('owners')} /></View>}
      <View style={vis('cows')}><CowsList nav={nav} active={on('cows')} /></View>
      {has('scan') && <View style={vis('scan')}><Scan nav={nav} active={on('scan')} /></View>}
      {has('register') && <View style={vis('register')}><Register nav={nav} active={on('register')} /></View>}
      {Top && <View style={{ flex: 1 }}><Top key={stack.length + top.name} {...top.params} nav={nav} /></View>}
      <View style={{ flexDirection: 'row', backgroundColor: '#fff', paddingTop: 8, paddingBottom: 12, borderTopLeftRadius: 24, borderTopRightRadius: 24, ...shadow, shadowOffset: { width: 0, height: -4 }, alignItems: 'flex-end' }}>
        {tabs.map(([k, icon, label, big]) => { const act = on(k); return (
          <TouchableOpacity key={k} onPress={() => nav.tab(k)} accessibilityRole="button" accessibilityLabel={label} style={{ flex: 1, alignItems: 'center' }}>
            {big ? (<View style={{ width: 56, height: 56, borderRadius: 28, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center', marginTop: -30, borderWidth: 4, borderColor: '#fff', ...shadow }}><Icon name={icon} size={28} color="#fff" /></View>)
              : (<View style={{ paddingHorizontal: 14, paddingVertical: 5, borderRadius: 14, backgroundColor: act ? C.soft : 'transparent' }}><Icon name={act ? icon : `${icon}-outline`} size={22} color={act ? C.primary : C.sub} /></View>)}
            <Text style={{ fontSize: 11, fontWeight: '700', marginTop: 2, color: act ? C.primary : C.sub }}>{label}</Text></TouchableOpacity>); })}
      </View>
    </View>);
}
