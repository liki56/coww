import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { C, Btn, Icon, Card } from '../ui';
import { GAP_MIN, GAP_MAX, MIN_CONF, TIMEOUT_MS } from '../config/capture';

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const KIND = { info: [C.soft, C.primary, 'information-circle'], good: ['#E8F7EE', C.ok, 'checkmark-circle'], warn: [C.amberSoft, C.amber, 'alert-circle'], bad: [C.dangerSoft, C.danger, 'close-circle'] };

// Smart camera: a photo is only KEPT when the server confirms a cow muzzle is in view and the photo is sharp enough.
// Frames without a muzzle are thrown away, so nothing random is ever saved.
export default function MuzzleCamera({ active, count, detectFn, checkFn, onDone, hint = 'Aim at the cow\'s nose pad and tap Start.' }) {
  const cam = useRef(null), stop = useRef(false), alive = useRef(true);
  const [perm, ask] = useCameraPermissions();
  const [ready, setReady] = useState(false), [busy, setBusy] = useState(false), [found, setFound] = useState(false), [kept, setKept] = useState(0);
  const [msg, setMsg] = useState({ t: hint, k: 'info' });
  const say = (t, k = 'info') => alive.current && setMsg({ t, k });
  useEffect(() => () => { alive.current = false; stop.current = true; }, []);
  useEffect(() => { if (!active) stop.current = true; }, [active]);

  if (!perm) return null;
  if (!perm.granted) return (<Card><Text style={{ color: C.text, marginBottom: 10 }}>SmartVet needs the camera to scan cow muzzles.</Text><Btn title="Allow camera" icon="camera" onPress={ask} /></Card>);

  const start = async () => {
    if (busy || !ready || !cam.current) return;
    stop.current = false; setBusy(true); setKept(0); setFound(false);
    const photos = []; const t0 = Date.now(); let misses = 0;
    try {
      while (photos.length < count && !stop.current) {
        if (Date.now() - t0 > TIMEOUT_MS) { say('No clear muzzle was found. Try again in better light, closer to the cow.', 'bad'); break; }
        const snap = await cam.current.takePictureAsync({ quality: 0.3, shutterSound: false });   // quick look; thrown away
        const d = await detectFn(snap);
        if (d.detail) { say(d.detail, 'bad'); break; }
        if (!d.found || d.conf < MIN_CONF) {
          setFound(false); misses += 1;
          say(misses >= 3 ? 'This is not a cow muzzle image. Aim at the wet, patterned nose pad.' : 'No cow muzzle in view. Point the camera at the nose pad.', misses >= 3 ? 'bad' : 'warn');
          await wait(700); continue;
        }
        misses = 0; setFound(true); say('Muzzle found. Hold steady...', 'good'); await wait(800);
        const pic = await cam.current.takePictureAsync({ quality: 0.8, shutterSound: false });
        const c = await checkFn(pic);
        if (c.detail) { say(c.detail, 'bad'); break; }
        if (!c.usable) { say(`Photo not kept: ${(c.reasons || []).join(', ')}. Hold steady and try again.`, 'warn'); await wait(1500); continue; }
        photos.push(pic); alive.current && setKept(photos.length);
        if (photos.length < count) {
          const gap = GAP_MIN + Math.floor(Math.random() * (GAP_MAX - GAP_MIN + 1));
          for (let sec = gap; sec > 0 && !stop.current; sec--) { say(`Photo ${photos.length} of ${count} saved. Next one in ${sec}s. Keep the muzzle in view.`, 'good'); await wait(1000); }
        }
      }
      if (photos.length === count && !stop.current) { say('All photos captured.', 'good'); onDone(photos); }
      else if (stop.current) say('Stopped.', 'info');
    } catch (e) { say('Camera problem: ' + String(e.message || e), 'bad'); }
    finally { alive.current && (setBusy(false), setFound(false)); }
  };

  const [bg, fg, ic] = KIND[msg.k];
  return (<View>
    <View style={s.box}>
      {active && <CameraView ref={cam} style={StyleSheet.absoluteFill} facing="back" onCameraReady={() => setReady(true)} />}
      <View pointerEvents="none" style={[s.guide, { borderColor: found ? '#4ADE80' : 'rgba(255,255,255,0.85)' }]} />
      <View style={s.counter}><Icon name="images" size={14} color="#fff" /><Text style={{ color: '#fff', fontWeight: '800', fontSize: 13 }}> {kept}/{count}</Text></View>
    </View>
    <View style={[s.status, { backgroundColor: bg }]}><Icon name={ic} size={20} color={fg} /><Text style={{ flex: 1, color: fg, fontWeight: '600' }}>{msg.t}</Text></View>
    {busy ? <Btn kind="danger" icon="stop-circle" title="Stop" onPress={() => { stop.current = true; }} full />
      : <Btn icon="scan" title={kept ? 'Start again' : 'Start'} onPress={start} disabled={!ready} full />}
  </View>);
}
const s = StyleSheet.create({
  box: { height: 380, borderRadius: 24, overflow: 'hidden', backgroundColor: '#0c1a13', justifyContent: 'center', alignItems: 'center' },
  guide: { width: '72%', height: '52%', borderWidth: 3, borderRadius: 24 },
  counter: { position: 'absolute', top: 14, right: 14, backgroundColor: 'rgba(0,0,0,0.55)', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 14, flexDirection: 'row', alignItems: 'center' },
  status: { flexDirection: 'row', gap: 10, alignItems: 'center', padding: 12, borderRadius: 14, marginVertical: 12 },
});
