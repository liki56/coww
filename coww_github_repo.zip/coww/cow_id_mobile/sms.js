import * as SMS from 'expo-sms';
import { Share } from 'react-native';

const dr = (n) => (/^dr\b/i.test((n || '').trim()) ? n.trim() : `Dr. ${n}`);
export const ownerMessage = ({ owner, cowId, doctor }) =>
  `Hello ${owner.name}, welcome to SmartVet. Your Owner ID is ${owner.owner_id}${cowId ? ` and your cow ${cowId} is now registered` : ''}. Please keep this ID safe. ` +
  `For any emergency contact ${dr(doctor.name)} on ${doctor.phone}.`;

// Opens the doctor's own SMS app with the message ready to send to the owner. The SMS leaves the DOCTOR'S PHONE and number.
export async function sendOwnerSms(args) {
  const text = ownerMessage(args);
  try {
    if (await SMS.isAvailableAsync()) { await SMS.sendSMSAsync([args.owner.phone], text); return true; }
  } catch {}
  await Share.share({ message: text });   // phones without SMS: share the text instead
  return false;
}
