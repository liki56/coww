import AsyncStorage from '@react-native-async-storage/async-storage';
import { API_URL } from './config/api';

let BASE = API_URL, TOKEN = null, unauth = () => {};
export const getBase = () => BASE;
export const setToken = (t) => { TOKEN = t; };
export const onUnauthorized = (f) => { unauth = f; };
export async function loadBase() { const s = await AsyncStorage.getItem('server_override'); BASE = (s || API_URL).replace(/\/+$/, ''); return BASE; }
export async function saveBase(u) {
  u = (u || '').trim().replace(/\/+$/, '');
  if (u) await AsyncStorage.setItem('server_override', u); else await AsyncStorage.removeItem('server_override');
  BASE = u || API_URL; return BASE;
}

// One request helper (XMLHttpRequest: reliable for photo uploads in Expo Go). Returns { ok, status, j }.
export function call(path, { method = 'GET', body, json } = {}) {
  return new Promise((resolve) => {
    if (!BASE) return resolve({ ok: false, status: 0, j: { detail: 'Server address is not set. Open "Server settings" on the sign-in screen.' } });
    const x = new XMLHttpRequest();
    x.open(method, BASE + path); x.timeout = 120000;
    if (TOKEN) x.setRequestHeader('Authorization', 'Bearer ' + TOKEN);
    if (json !== undefined) x.setRequestHeader('Content-Type', 'application/json');
    x.onload = () => {
      let j = {}; try { j = JSON.parse(x.responseText); } catch {}
      if (x.status === 401 && path !== '/api/auth/login') unauth();
      if (x.status >= 500) j = { detail: 'The server had a problem. Please try again.' };
      else if (Array.isArray(j.detail)) j = { ...j, detail: 'Please check the form and try again.' };
      resolve({ ok: x.status >= 200 && x.status < 300, status: x.status, j });
    };
    x.onerror = () => resolve({ ok: false, status: 0, j: { detail: 'Cannot reach the server. Check your internet connection and the server address.' } });
    x.ontimeout = () => resolve({ ok: false, status: 0, j: { detail: 'The server took too long to respond.' } });
    x.send(json !== undefined ? JSON.stringify(json) : body || null);
  });
}
export const get = (p) => call(p);
export const send = (p, method, json) => call(p, { method, json });
export const errText = (r) => (typeof r?.j?.detail === 'string' && r.j.detail) || r?.j?.message || 'Something went wrong. Please try again.';
export function form(fields, photos = [], extra = {}) {
  const fd = new FormData();
  Object.entries(fields).forEach(([k, v]) => { if (v !== undefined && v !== null) fd.append(k, String(v)); });
  photos.forEach((p, i) => fd.append('photos', { uri: p.uri, name: `p${i}.jpg`, type: 'image/jpeg' }));
  Object.entries(extra).forEach(([k, p]) => p && fd.append(k, { uri: p.uri, name: `${k}.jpg`, type: 'image/jpeg' }));
  return fd;
}
// Cow photos need the login token, so they are loaded with an Authorization header.
export const imgSource = (cowId, v) => ({ uri: `${BASE}/api/cows/${encodeURIComponent(cowId)}/image${v ? '?v=' + v : ''}`, headers: TOKEN ? { Authorization: 'Bearer ' + TOKEN } : {} });
// Sends ONE camera frame to a helper endpoint (/api/detect or /api/check) and returns its JSON answer.
export const oneFile = (path) => async (p) => (await call(path, { method: 'POST', body: form({}, [p]) })).j;
