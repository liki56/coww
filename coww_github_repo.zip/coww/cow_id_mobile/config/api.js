// ONE place for the backend address. Set it in the .env file next to package.json, then restart: npx expo start --clear
export const API_URL = (process.env.EXPO_PUBLIC_API_URL || '').trim().replace(/\/+$/, '');
