// Camera behaviour in one place.
export const SCAN_PHOTOS = 3;       // muzzle photos taken when scanning a cow
export const REGISTER_PHOTOS = 5;   // muzzle photos taken when registering a cow
export const GAP_MIN = 5;           // seconds between photos (random between min and max)
export const GAP_MAX = 10;
export const MIN_CONF = 0.6;        // how sure the detector must be that it sees a muzzle before a photo is taken
export const TIMEOUT_MS = 180000;   // stop searching after this long
