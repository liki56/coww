import React, { useState } from 'react';
import { View, Text, TouchableOpacity, TextInput, ScrollView, ActivityIndicator, Alert, StyleSheet, RefreshControl, Image, StatusBar as RNStatusBar } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { imgSource } from './api';

export const C = { primary: '#0B6E4F', dark: '#08543D', soft: '#E3F3EC', bg: '#F3F6F4', card: '#FFFFFF', text: '#13261C', sub: '#667A6F', line: '#E1E8E3',
  amber: '#D9930D', amberSoft: '#FEF3D6', danger: '#D93B3B', dangerSoft: '#FDECEC', info: '#2563EB', infoSoft: '#E6EEFD', ok: '#16A34A' };
export const shadow = { shadowColor: '#0B3D2A', shadowOpacity: 0.08, shadowRadius: 12, shadowOffset: { width: 0, height: 4 }, elevation: 3 };
export const Icon = ({ name, size = 20, color = C.text, style }) => <Ionicons name={name} size={size} color={color} style={style} />;
export const fmt = (s) => { if (!s) return '-'; const d = new Date(String(s).slice(0, 10) + 'T00:00:00'); return isNaN(d) ? s : d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }); };
export const confirm = (title, msg, onYes, label = 'Confirm', destructive = false) =>
  Alert.alert(title, msg, [{ text: 'Cancel', style: 'cancel' }, { text: label, style: destructive ? 'destructive' : 'default', onPress: onYes }]);

export function Avatar({ name = '?', size = 44, bg = C.soft, fg = C.primary }) {
  const t = name.trim().split(/\s+/).slice(0, 2).map((w) => w[0]?.toUpperCase()).join('') || '?';
  return <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: bg, alignItems: 'center', justifyContent: 'center' }}><Text style={{ color: fg, fontWeight: '800', fontSize: size * 0.38 }}>{t}</Text></View>;
}
export function CowImage({ id, has, size = 56, radius = 14, v, style }) {
  const [bad, setBad] = useState(false);
  if (!has || bad) return <View style={[{ width: size, height: size, borderRadius: radius, backgroundColor: C.soft, alignItems: 'center', justifyContent: 'center' }, style]}><Icon name="paw" size={size * 0.45} color={C.primary} /></View>;
  return <Image source={imgSource(id, v)} onError={() => setBad(true)} style={[{ width: size, height: size, borderRadius: radius, backgroundColor: C.soft }, style]} />;
}
export const Card = ({ children, style, onPress }) => onPress
  ? <TouchableOpacity activeOpacity={0.75} onPress={onPress} accessibilityRole="button" style={[s.card, style]}>{children}</TouchableOpacity>
  : <View style={[s.card, style]}>{children}</View>;
export function Btn({ title, onPress, kind = 'primary', icon, full, disabled, loading, small, style }) {
  const k = { primary: [C.primary, '#fff', C.primary], soft: [C.soft, C.primary, C.soft], outline: ['#fff', C.primary, C.primary], danger: ['#fff', C.danger, C.danger], dangerSolid: [C.danger, '#fff', C.danger], light: ['#fff', C.primary, '#fff'], ghost: ['transparent', C.primary, 'transparent'] }[kind];
  return (<TouchableOpacity onPress={onPress} disabled={disabled || loading} accessibilityRole="button" activeOpacity={0.8}
    style={[s.btn, { backgroundColor: k[0], borderColor: k[2] }, small && { paddingVertical: 9, paddingHorizontal: 14 }, full && { alignSelf: 'stretch' }, (disabled || loading) && { opacity: 0.5 }, style]}>
    {loading ? <ActivityIndicator color={k[1]} size="small" /> : icon ? <Icon name={icon} size={small ? 16 : 18} color={k[1]} /> : null}
    <Text style={[s.btnT, { color: k[1] }, small && { fontSize: 13 }]}>{title}</Text></TouchableOpacity>);
}
export function Field({ label, icon, error, right, multiline, style, ...p }) {
  const [focus, setFocus] = useState(false);
  return (<View style={[{ marginBottom: 14 }, style]}>
    {label ? <Text style={s.label}>{label}</Text> : null}
    <View style={[s.inputWrap, focus && { borderColor: C.primary }, error && { borderColor: C.danger }, multiline && { alignItems: 'flex-start' }]}>
      {icon ? <Icon name={icon} size={18} color={C.sub} style={multiline ? { marginTop: 12 } : null} /> : null}
      <TextInput style={[s.input, multiline && { minHeight: 84, textAlignVertical: 'top' }]} placeholderTextColor="#9BAAA1" multiline={multiline}
        onFocus={() => setFocus(true)} onBlur={() => setFocus(false)} {...p} />{right}
    </View>{error ? <Text style={s.err}>{error}</Text> : null}</View>);
}
export const Chip = ({ label, on, onPress, icon }) => (
  <TouchableOpacity onPress={onPress} accessibilityRole="button" style={[s.chip, on && { backgroundColor: C.primary, borderColor: C.primary }]}>
    {icon ? <Icon name={icon} size={14} color={on ? '#fff' : C.sub} /> : null}<Text style={[s.chipT, on && { color: '#fff' }]}>{label}</Text></TouchableOpacity>);
export const Chips = ({ children }) => <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 8 }}>{children}</View>;
export function Segmented({ options, value, onChange }) {
  return (<View style={{ flexDirection: 'row', backgroundColor: '#E6ECE8', borderRadius: 14, padding: 4, marginBottom: 16 }}>
    {options.map(([k, l]) => (<TouchableOpacity key={k} onPress={() => onChange(k)} style={[{ flex: 1, paddingVertical: 10, borderRadius: 11, alignItems: 'center' }, value === k && { backgroundColor: '#fff', ...shadow, elevation: 1 }]}>
      <Text style={{ fontWeight: '700', fontSize: 13, color: value === k ? C.primary : C.sub }}>{l}</Text></TouchableOpacity>))}</View>);
}
const TONE = { green: [C.ok, '#E8F7EE'], amber: [C.amber, C.amberSoft], red: [C.danger, C.dangerSoft], blue: [C.info, C.infoSoft], grey: [C.sub, '#ECF0ED'] };
export const Badge = ({ text, tone = 'grey', icon }) => { const [fg, bg] = TONE[tone];
  return <View style={{ backgroundColor: bg, paddingHorizontal: 9, paddingVertical: 4, borderRadius: 10, alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 4 }}>
    {icon ? <Icon name={icon} size={12} color={fg} /> : null}<Text style={{ color: fg, fontSize: 11, fontWeight: '800' }}>{text}</Text></View>; };
export const Stat = ({ icon, value, label, color = C.primary, soft = C.soft, onPress }) => (
  <Card onPress={onPress} style={{ width: '48%', marginBottom: 12, padding: 14 }}>
    <View style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: soft, alignItems: 'center', justifyContent: 'center' }}><Icon name={icon} color={color} size={22} /></View>
    <Text style={{ fontSize: 28, fontWeight: '800', color: C.text, marginTop: 10 }}>{value ?? '-'}</Text><Text style={{ color: C.sub, fontSize: 13 }}>{label}</Text></Card>);
export const Grid = ({ children }) => <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }}>{children}</View>;
export const Section = ({ title, right, children }) => (
  <View style={{ marginTop: 18 }}><View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
    <Text style={{ fontSize: 13, fontWeight: '800', color: C.sub, textTransform: 'uppercase', letterSpacing: 0.8 }}>{title}</Text>{right}</View>{children}</View>);
export const KV = ({ icon, k, v }) => (v === undefined || v === null || v === '') ? null : (
  <View style={{ flexDirection: 'row', paddingVertical: 7, alignItems: 'flex-start' }}>
    {icon ? <Icon name={icon} size={18} color={C.sub} style={{ width: 28, marginTop: 1 }} /> : null}
    <Text style={{ width: 96, color: C.sub, fontSize: 14 }}>{k}</Text><Text style={{ flex: 1, color: C.text, fontSize: 14, fontWeight: '600' }} selectable>{String(v)}</Text></View>);
export const Empty = ({ icon = 'paw', title, text }) => (
  <View style={{ alignItems: 'center', padding: 36 }}><View style={{ width: 72, height: 72, borderRadius: 36, backgroundColor: C.soft, alignItems: 'center', justifyContent: 'center' }}><Icon name={icon} size={32} color={C.primary} /></View>
    {title ? <Text style={{ fontWeight: '800', color: C.text, fontSize: 16, marginTop: 12 }}>{title}</Text> : null}<Text style={{ color: C.sub, marginTop: 4, textAlign: 'center' }}>{text}</Text></View>);
export const Loading = () => <ActivityIndicator color={C.primary} size="large" style={{ marginTop: 50 }} />;
export const ErrorBox = ({ text, onRetry }) => (
  <Card style={{ borderLeftWidth: 5, borderLeftColor: C.danger }}><View style={{ flexDirection: 'row', gap: 10 }}><Icon name="alert-circle" color={C.danger} size={22} /><Text style={{ flex: 1, color: C.text }}>{text}</Text></View>
    {onRetry ? <Btn small kind="outline" title="Try again" icon="refresh" onPress={onRetry} style={{ marginTop: 10 }} /> : null}</Card>);
export const Msg = ({ ok, text, style }) => !text ? null : (
  <Card style={[{ borderLeftWidth: 5, borderLeftColor: ok ? C.ok : C.danger, marginTop: 10 }, style]}><View style={{ flexDirection: 'row', gap: 10 }}>
    <Icon name={ok ? 'checkmark-circle' : 'alert-circle'} color={ok ? C.ok : C.danger} size={22} /><Text style={{ flex: 1, color: C.text }}>{text}</Text></View></Card>);
export const SearchBar = (p) => <Field icon="search" placeholder="Search" returnKeyType="search" {...p} style={{ marginBottom: 10 }} />;

export function Page({ title, subtitle, onBack, right, children, onRefresh, refreshing = false, footer, flat }) {
  return (<View style={{ flex: 1, backgroundColor: C.bg }}>
    <View style={s.header}><View style={{ flexDirection: 'row', alignItems: 'center' }}>
      {onBack ? <TouchableOpacity onPress={onBack} accessibilityLabel="Back" style={s.back}><Icon name="chevron-back" size={22} color="#fff" /></TouchableOpacity> : null}
      <View style={{ flex: 1 }}><Text style={s.title} numberOfLines={1}>{title}</Text>{subtitle ? <Text style={s.subtitle} numberOfLines={1}>{subtitle}</Text> : null}</View>{right}</View></View>
    <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: 16, paddingBottom: footer ? 20 : 40 }}
      refreshControl={onRefresh ? <RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[C.primary]} /> : undefined}>{children}</ScrollView>
    {footer ? <View style={s.footer}>{footer}</View> : null}
  </View>);
}

const s = StyleSheet.create({
  header: { backgroundColor: C.primary, paddingTop: (RNStatusBar.currentHeight || 44) + 8, paddingBottom: 22, paddingHorizontal: 18, borderBottomLeftRadius: 28, borderBottomRightRadius: 28 },
  back: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(255,255,255,0.18)', alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  title: { color: '#fff', fontSize: 21, fontWeight: '800' }, subtitle: { color: '#CBEBDC', fontSize: 13, marginTop: 1 },
  card: { backgroundColor: C.card, borderRadius: 18, padding: 14, marginBottom: 12, ...shadow },
  btn: { flexDirection: 'row', gap: 8, paddingVertical: 14, paddingHorizontal: 20, borderRadius: 14, borderWidth: 1.5, alignItems: 'center', justifyContent: 'center', alignSelf: 'flex-start', marginVertical: 4 },
  btnT: { fontSize: 15, fontWeight: '700' },
  label: { fontSize: 13, color: C.sub, marginBottom: 6, fontWeight: '700' },
  inputWrap: { flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 1.5, borderColor: C.line, borderRadius: 14, paddingHorizontal: 14, backgroundColor: '#fff' },
  input: { flex: 1, paddingVertical: 13, fontSize: 16, color: C.text }, err: { color: C.danger, fontSize: 12, marginTop: 4 },
  chip: { flexDirection: 'row', gap: 5, alignItems: 'center', paddingVertical: 8, paddingHorizontal: 14, borderRadius: 18, borderWidth: 1.5, borderColor: C.line, backgroundColor: '#fff', marginRight: 8, marginBottom: 8 },
  chipT: { color: C.text, fontSize: 13, fontWeight: '700' },
  footer: { backgroundColor: '#fff', padding: 14, paddingBottom: 18, flexDirection: 'row', gap: 10, borderTopWidth: 1, borderTopColor: C.line },
});
