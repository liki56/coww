# Go-Naasika: BIOMUZZLE-ID

**Cow identification for veterinary care using the unique muzzle (nose) pattern.**
Final-year project, Dept. of CSE (AI & ML), JSS Academy of Technical Education, Bengaluru.

Team: Prakruthi B R (1JS24CI405), Sunil A M (1JS24CI408), V Likitha (1JS24CI411), Namitha C S (1JS23CI053)
Guide: Dr. B. Gayathri Kamath, Assistant Professor, Dept. of CSE (AI & ML)

## Why
Ear tags, brands and RFID can be lost, damaged or swapped, and small farmers often cannot afford RFID. A cow's muzzle pattern is unique, like a fingerprint. A phone camera is enough to read it.

## How it works
```
Camera photo -> YOLOv8n (find muzzle) -> quality check (sharp, big, no glare)
             -> ResNet50 embedding (2048 numbers) -> cosine similarity: top-3 cows
             -> SIFT + RANSAC verification of the nose pattern
Decision: MATCH (8+ inliers) | POSSIBLE (5-7, doctor checks) | NEW COW (<5) | RETAKE (bad photo)
```
![Architecture](docs/images/architecture.jpg)

| Tier | Technology |
|---|---|
| Mobile app | Expo / React Native (`cow_id_mobile/`) |
| Backend | Python, FastAPI, YOLOv8, PyTorch ResNet50, OpenCV (`cow_id_backend/`) |
| Database | MongoDB Atlas (cows, owners, doctors, muzzle samples) |

The app talks only to the backend, so database credentials never reach the phone. Scan photos are never stored.

## Features
- Two roles: **Admin** (creates doctors, views all owners and cows) and **Doctor** (scans and registers cows).
- Camera captures a photo **only when a muzzle is detected**, 5 to 10 seconds apart.
- Registration: owner (existing ID or new), cow details and age, 5 muzzle photos, 1 full-body photo.
- Duplicate-cow check before registering.
- New owner: SMS with Owner ID and Cow ID is sent from the doctor's own phone.
- Login required; passwords hashed; role checks enforced on the server.

## Results
| Measure | Value |
|---|---|
| Dataset | 37 cows, 661 photos, 608 muzzles detected, 597 sharp crops kept |
| YOLOv8n detector | Precision 0.999, recall 1.0, mAP50 0.995, mAP50-95 0.792, 6.3 MB |
| Full pipeline (held out, 29 cows, 3 folds, 455 scans) | **92.3% correct, 0 wrong cows** |
| ResNet50 + cosine only | 41.4% correct |
| Stranger cows accepted | 0 of 54 |

Limits: the test most likely used same-session photos and small groups of cows. Accuracy on other days, phones and a larger herd still has to be measured.

## Run it
### 1. Backend
```bash
cd cow_id_backend
python -m venv .venv
source .venv/Scripts/activate        # Windows Git Bash. Mac/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env                 # then edit MONGODB_URI and the admin password
# put your trained detector at: models/muzzle_det_best.pt   (not in this repo)
python run.py                        # http://localhost:8000/docs
```
### 2. Mobile app
```bash
cd cow_id_mobile
cp .env.example .env                 # set EXPO_PUBLIC_API_URL
npm install
npm run setup
npx expo start --clear               # scan the QR code with Expo Go
```
Full details: [backend README](cow_id_backend/README.md), [mobile README](cow_id_mobile/README.md).

## Deployment
The backend needs about 2 GB RAM (a 512 MB Render instance was too small). Use Docker plus a domain for a fixed HTTPS address: `docker compose up -d --build` in `cow_id_backend/`.

## Not in this repo (add yourself)
- `cow_id_backend/models/muzzle_det_best.pt` (trained YOLOv8n weights, from Roboflow)
- `.env` files with your MongoDB URI and admin password. **Never commit them.**

## Data
Own phone photos (private) and the public Zenodo dataset, *Beef Cattle Muzzle/Noseprint Database* (https://zenodo.org/records/6324361). Check its licence before reuse.

## Future work
Second-day test set and more cows, ensemble or DINOv2 embeddings, vaccination reminders and health reports, final cloud hosting.
