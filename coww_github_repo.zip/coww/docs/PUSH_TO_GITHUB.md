# Push to https://github.com/liki56/coww.git
Run inside the `coww` folder (Git Bash):
```bash
git init
git add .
git status            # check that no .env file and no .pt file is listed
git commit -m "Go-Naasika BIOMUZZLE-ID: backend, mobile app, docs"
git branch -M main
git remote add origin https://github.com/liki56/coww.git
git push -u origin main
```
If the remote already has a README commit: `git pull origin main --allow-unrelated-histories` first, then push.
