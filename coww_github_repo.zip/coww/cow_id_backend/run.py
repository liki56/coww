import socket
import uvicorn


def lan_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))   # no data is sent; just finds the active network adapter
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


if __name__ == "__main__":
    print(f"\n>>> Enter this address in the mobile app: http://{lan_ip()}:8000\n")
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000)