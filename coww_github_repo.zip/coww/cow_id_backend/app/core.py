"""Engine: YOLO nose crop -> quality gate -> ResNet50 embedding top-k -> SIFT+RANSAC verification."""
import threading
import numpy as np, cv2, torch, torch.nn as nn, torch.nn.functional as F, torchvision.models as tvm
from PIL import Image, ImageOps
from . import config as C, db

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MEAN = torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1)
STD = torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1)
_clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
_unit = lambda v: v / np.linalg.norm(v)
_png = lambda g: cv2.imencode(".png", g)[1].tobytes()
_unpng = lambda b: cv2.imdecode(np.frombuffer(b, np.uint8), cv2.IMREAD_GRAYSCALE)


def to_gray224(pil):
    w, h = pil.size
    if w / h > 4 / 3:
        nw = int(h * 4 / 3); x0 = (w - nw) // 2; pil = pil.crop((x0, 0, x0 + nw, h))
    elif h / w > 4 / 3:
        nh = int(w * 4 / 3); y0 = (h - nh) // 2; pil = pil.crop((0, y0, w, y0 + nh))
    g = np.array(pil.convert("L"))
    g = cv2.resize(g, (C.IMG, C.IMG), interpolation=cv2.INTER_AREA if min(g.shape) >= C.IMG else cv2.INTER_CUBIC)
    return _clahe.apply(g)


class Engine:
    def __init__(self):
        if not C.DET_WEIGHTS.exists():
            raise FileNotFoundError(f"Detector weights not found: {C.DET_WEIGHTS}\n"
                                    "Put your muzzle_det_best.pt in the models/ folder (see README).")
        from ultralytics import YOLO
        self.det = YOLO(str(C.DET_WEIGHTS))
        m = tvm.resnet50(weights=tvm.ResNet50_Weights.IMAGENET1K_V2); m.fc = nn.Identity()   # downloaded once
        self.model = m.to(DEVICE).eval()
        self.bf, self.lock, self._sc = cv2.BFMatcher(), threading.RLock(), {}
        self.gal = {}
        for cid in db.cow_ids_with_samples(): self._load(cid)
        print(f"engine ready on {DEVICE}: {len(self.gal)} cows loaded")

    def _load(self, cid):
        s = db.samples(cid)
        self.gal[cid] = dict(ids=[i for i, _, _ in s], emb=np.stack([e for _, e, _ in s]), gray=[_unpng(b) for _, _, b in s])

    def drop(self, cid):
        with self.lock:
            g = self.gal.pop(cid, None)
            for i in (g or {}).get("ids", []): self._sc.pop(i, None)

    # ---- steps ----
    def prepare(self, src):
        """photo -> (gray224, sharpness, reasons). Non-empty reasons = retake."""
        try:
            pil = ImageOps.exif_transpose(Image.open(src)).convert("RGB")
        except Exception:
            return None, 0.0, ["not a readable image"]
        r = self.det.predict(np.array(pil)[:, :, ::-1], conf=0.25, imgsz=640, verbose=False)[0]
        if len(r.boxes) == 0: return None, 0.0, ["no nose found"]
        i = int(r.boxes.conf.argmax()); conf = float(r.boxes.conf[i])
        x1, y1, x2, y2 = r.boxes.xyxy[i].tolist(); w, h = pil.size; bw, bh = x2 - x1, y2 - y1
        crop = pil.crop((int(max(0, x1 - .08 * bw)), int(max(0, y1 - .08 * bh)), int(min(w, x2 + .08 * bw)), int(min(h, y2 + .08 * bh))))
        g = np.array(crop.convert("L")); ch, cw = g.shape
        g2 = cv2.resize(g, (C.IMG, C.IMG), interpolation=cv2.INTER_AREA if min(ch, cw) >= C.IMG else cv2.INTER_CUBIC)
        sharp, glare = float(cv2.Laplacian(g2, cv2.CV_64F).var()), float((g2 >= 245).mean()); why = []
        if conf < C.Q_MIN_CONF: why.append("nose not clear")
        if min(ch, cw) < C.Q_MIN_SIDE: why.append("too small: move closer")
        if glare > C.Q_MAX_GLARE: why.append("glare: shade the nose")
        if sharp < C.SHARP_THR: why.append("blurry: hold steady")
        return to_gray224(crop), sharp, why

    @torch.no_grad()
    def embed(self, grays):
        x = torch.stack([(torch.from_numpy(g).float().div(255).unsqueeze(0).repeat(3, 1, 1) - MEAN) / STD for g in grays]).to(DEVICE)
        return F.normalize(self.model(x).float(), dim=1).cpu().numpy()

    def _sift(self, g):
        h, w = g.shape; m = np.zeros_like(g)
        m[int(h * (1 - C.CENTER) / 2):int(h * (1 + C.CENTER) / 2), int(w * (1 - C.CENTER) / 2):int(w * (1 + C.CENTER) / 2)] = 255
        k, d = cv2.SIFT_create(nfeatures=1500).detectAndCompute(g, m)
        return (np.float32([p.pt for p in k]) if k else np.zeros((0, 2), np.float32)), d

    def _gsift(self, cid, j):
        sid = self.gal[cid]["ids"][j]
        if sid not in self._sc: self._sc[sid] = self._sift(self.gal[cid]["gray"][j])
        return self._sc[sid]

    def _inl(self, a, b, ratio=0.75):
        (pa, da), (pb, db_) = a, b
        if da is None or db_ is None or len(pa) < 8 or len(pb) < 8: return 0
        good = [x[0] for x in self.bf.knnMatch(da, db_, k=2) if len(x) == 2 and x[0].distance < ratio * x[1].distance]
        if len(good) < 8: return 0
        _, mk = cv2.findHomography(pa[[q.queryIdx for q in good]].reshape(-1, 1, 2), pb[[q.trainIdx for q in good]].reshape(-1, 1, 2), cv2.RANSAC, 5.0)
        return 0 if mk is None else int(mk.sum())

    def identify_gray(self, g):
        if not self.gal: return dict(status="NEW COW", cow_id=None, candidates=[], top_inliers=0)
        e = self.embed([g])[0]; names = sorted(self.gal)
        s = np.stack([_unit(self.gal[n]["emb"].mean(0)) for n in names]) @ e
        fq, cands = self._sift(g), []
        for k in np.argsort(-s)[:C.TOPK]:
            n = names[k]
            inl = max(self._inl(fq, self._gsift(n, j)) for j in range(len(self.gal[n]["gray"])))
            cands.append(dict(cow_id=n, embed_score=round(float(s[k]), 3), sift_inliers=int(inl)))
        top = max(cands, key=lambda d: d["sift_inliers"])
        if top["sift_inliers"] >= C.SIFT_MATCH: st, cid = "MATCH", top["cow_id"]
        elif top["sift_inliers"] >= C.SIFT_POSSIBLE: st, cid = "POSSIBLE", top["cow_id"]
        elif cands[0]["embed_score"] >= C.EMBED_POSSIBLE: st, cid = "POSSIBLE", cands[0]["cow_id"]
        else: st, cid = "NEW COW", None
        return dict(status=st, cow_id=cid, candidates=cands, top_inliers=top["sift_inliers"])

    def detect(self, src):
        """Fast presence test for live scanning: is a nose in view? (YOLO only, nothing stored)"""
        with self.lock:
            try:
                pil = ImageOps.exif_transpose(Image.open(src)).convert("RGB")
            except Exception:
                return dict(found=False, conf=0.0)
            r = self.det.predict(np.array(pil)[:, :, ::-1], conf=0.25, imgsz=640, verbose=False)[0]
            if len(r.boxes) == 0: return dict(found=False, conf=0.0)
            return dict(found=True, conf=round(float(r.boxes.conf.max()), 2))

    def check(self, src):
        """Full quality check of one photo (blur, size, glare, nose confidence)."""
        with self.lock:
            _, _, why = self.prepare(src)
            return dict(usable=not why, reasons=why)

    # ---- public API ----
    def scan(self, srcs):
        """1-3 photos of the same cow. MATCH only if the usable photos agree."""
        with self.lock:
            per = []
            for p in srcs:
                g, _, why = self.prepare(p)
                per.append(dict(status="RETAKE", reasons=why) if why else self.identify_gray(g))
            ok = [r for r in per if r["status"] != "RETAKE"]
            if not ok:
                return dict(status="RETAKE", reasons=sorted({x for r in per for x in r["reasons"]}), candidates=[], cow_id=None)
            best = max(ok, key=lambda r: r["top_inliers"]); out = dict(candidates=best["candidates"], photos_used=len(ok), photos_sent=len(per))
            m = {r["cow_id"] for r in ok if r["status"] == "MATCH"}
            if len(m) == 1: return dict(out, status="MATCH", cow_id=m.pop())
            if len(m) > 1: return dict(out, status="POSSIBLE", cow_id=None, note="photos disagree: retake")
            p = [r for r in ok if r["status"] == "POSSIBLE"]
            if p: return dict(out, status="POSSIBLE", cow_id=max(p, key=lambda r: r["top_inliers"])["cow_id"])
            return dict(out, status="NEW COW", cow_id=None)

    def register(self, cow_id, details, srcs, force=False):
        """New cow (details given) or extra photos for an existing cow."""
        with self.lock:
            exists = db.get_cow(cow_id)
            use, rej = [], {}
            for i, p in enumerate(srcs):
                g, sh, why = self.prepare(p)
                if why: rej[i + 1] = why
                else: use.append((sh, g))
            need = 1 if exists else C.MIN_ENROLL
            if len(use) < need:
                return dict(ok=False, message=f"Only {len(use)} usable photos (need {need}+). Retake the rejected ones.", rejected=rej)
            room = C.MAX_SAMPLES - (exists["n_photos"] if exists else 0)
            if room <= 0: return dict(ok=False, message=f"{cow_id} already has {C.MAX_SAMPLES} photos.", rejected=rej)
            use = sorted(use, key=lambda t: -t[0])[:min(C.KEEP_PER_CALL, room)]
            if not exists and not force and self.gal:
                d = self.identify_gray(use[0][1])
                if d["status"] in ("MATCH", "POSSIBLE"):
                    return dict(ok=False, duplicate=d, rejected=rej,
                                message=f"This looks like {d['cow_id']}, already registered. Check, or register anyway.")
            grays = [g for _, g in use]
            if not exists: db.add_cow(cow_id, details)
            db.add_samples(cow_id, self.embed(grays), [_png(g) for g in grays], [s for s, _ in use])
            self._load(cow_id)
            return dict(ok=True, message=f"{'Added' if exists else 'Registered'} {cow_id}: {len(grays)} photos stored.", rejected=rej)