import io
from typing import List, Optional
from fastapi import Depends, FastAPI, File, Form, HTTPException, Response, UploadFile
from fastapi.responses import JSONResponse
from PIL import Image, ImageOps
from . import auth, db
from .api_people import need, phone10, router as people_router
from .auth import require

db.init()
auth.seed_admin()
from .core import Engine          # noqa: E402  (ML engine: unchanged; loads muzzle samples from MongoDB)
eng = Engine()
app = FastAPI(title="SmartVet")   # interactive API docs: /docs
app.include_router(people_router)
BOTH = ("ADMIN", "DOCTOR")


def files(fs): return [io.BytesIO(f.file.read()) for f in fs]


def jpeg(raw, side=900):
    try:
        im = ImageOps.exif_transpose(Image.open(io.BytesIO(raw))).convert("RGB")
    except Exception:
        raise HTTPException(422, "The full cow photo could not be read. Please take it again.")
    im.thumbnail((side, side)); b = io.BytesIO(); im.save(b, "JPEG", quality=80); return b.getvalue()


def cow_or_404(cow_id):
    c = db.get_cow(cow_id)
    if not c: raise HTTPException(404, "Cow not found.")
    return c


def valid_months(y, m):
    if y < 0 or m < 0 or m > 11 or y > 40: raise HTTPException(422, "Enter the cow's age as years (0-40) and months (0-11).")
    return y * 12 + m


@app.get("/")
def root(): return dict(app="SmartVet", docs="/docs")


@app.get("/api/health")
def health(): return dict(ok=True, cows_loaded=len(eng.gal))


@app.get("/api/dashboard")
def dashboard(u=Depends(require(*BOTH))):
    return dict(role=u["role"], **db.stats(u["ref_id"] if u["role"] == "DOCTOR" else None))


@app.get("/api/cows")
def cows(q: str = "", owner_id: str = "", unowned: bool = False, u=Depends(require(*BOTH))):
    return db.list_cows(q, owner_id.strip().upper() or None, unowned)


@app.get("/api/cows/{cow_id}")
def cow(cow_id: str, u=Depends(require(*BOTH))):
    c = cow_or_404(cow_id)
    c["owner"] = db.get_owner(c["owner_id"]) if c.get("owner_id") else None
    return c


@app.get("/api/cows/{cow_id}/image")
def cow_image(cow_id: str, u=Depends(require(*BOTH))):
    img = db.get_image(cow_id)
    if not img: raise HTTPException(404, "No photo for this cow.")
    return Response(img, media_type="image/jpeg", headers={"Cache-Control": "private, max-age=3600"})


@app.post("/api/cows")
def register(cow_id: str = Form(""), name: str = Form(""), breed: str = Form(""), sex: str = Form(""), color: str = Form(""),
             age_years: int = Form(0), age_months: int = Form(0), location: str = Form(""), notes: str = Form(""),
             owner_id: str = Form(""), new_owner_name: str = Form(""), new_owner_phone: str = Form(""),
             new_owner_address: str = Form(""), new_owner_village: str = Form(""), force: bool = Form(False),
             photos: List[UploadFile] = File(...), full_image: UploadFile = File(...), u=Depends(require("DOCTOR"))):
    """Doctor registers a cow: muzzle photos (identification) + full cow photo + details + owner (existing ID, new owner, or none)."""
    cid = cow_id.strip()
    if cid and db.get_cow(cid): raise HTTPException(409, f"Cow ID {cid} is already registered.")
    cid = cid or db.next_code("cows", "COW", 4)
    months = valid_months(age_years, age_months)
    existing, new_owner = None, None
    if owner_id.strip():
        existing = db.get_owner(owner_id.strip().upper())
        if not existing: raise HTTPException(422, "Owner ID not found. Check the ID or create a new owner.")
    elif new_owner_name.strip():
        new_owner = dict(name=need(new_owner_name, "Owner name"), phone=phone10(new_owner_phone), address=need(new_owner_address, "Owner address"), village=new_owner_village.strip())
    image = jpeg(full_image.file.read())
    details = dict(name=name.strip(), breed=breed.strip(), sex=sex.strip(), color=color.strip(), age_months=months, location=location.strip(), notes=notes.strip(),
                   owner_id=existing["owner_id"] if existing else None, registered_by=u["ref_id"], registered_by_name=u["name"])
    r = eng.register(cid, details, files(photos), force)       # muzzle quality check, duplicate check, embeddings: unchanged engine
    if not r["ok"]: return JSONResponse(r, 409 if "duplicate" in r else 422)
    db.set_image(cid, image)
    owner = existing
    if new_owner:
        oid = db.add_owner(new_owner, u); db.update_cow(cid, {"owner_id": oid}, u["username"]); owner = db.get_owner(oid)
    return dict(ok=True, cow_id=cid, message=f"Cow {cid} registered.", owner=owner, owner_created=bool(new_owner), cow=db.get_cow(cid))


@app.put("/api/cows/{cow_id}")
def edit(cow_id: str, name: Optional[str] = Form(None), breed: Optional[str] = Form(None), sex: Optional[str] = Form(None),
         color: Optional[str] = Form(None), age_years: Optional[int] = Form(None), age_months: Optional[int] = Form(None),
         location: Optional[str] = Form(None), notes: Optional[str] = Form(None), owner_id: Optional[str] = Form(None), u=Depends(require(*BOTH))):
    cow_or_404(cow_id)
    d = dict(name=name, breed=breed, sex=sex, color=color, location=location, notes=notes)
    if age_years is not None or age_months is not None: d["age_months"] = valid_months(age_years or 0, age_months or 0)
    if owner_id is not None:
        if owner_id.strip():
            o = db.get_owner(owner_id.strip().upper())
            if not o: raise HTTPException(422, "Owner ID not found.")
            d["owner_id"] = o["owner_id"]
        else: d["owner_id"] = ""
    db.update_cow(cow_id, d, u["username"]); return db.get_cow(cow_id)


@app.delete("/api/cows/{cow_id}")
def remove(cow_id: str, u=Depends(require("ADMIN"))):
    cow_or_404(cow_id); db.delete_cow(cow_id); eng.drop(cow_id); return dict(ok=True)


# ---- live camera helpers + identification (doctor only). Nothing from a scan is saved. ----
@app.post("/api/detect")
def detect(photos: List[UploadFile] = File(...), u=Depends(require("DOCTOR"))): return eng.detect(io.BytesIO(photos[0].file.read()))


@app.post("/api/check")
def check(photos: List[UploadFile] = File(...), u=Depends(require("DOCTOR"))): return eng.check(io.BytesIO(photos[0].file.read()))


@app.post("/api/scan")
def scan(photos: List[UploadFile] = File(...), u=Depends(require("DOCTOR"))):
    r = eng.scan(files(photos[:3]))
    c = db.get_cow(r["cow_id"]) if r.get("cow_id") else None
    r["cow"], r["owner"] = c, (db.get_owner(c["owner_id"]) if c and c.get("owner_id") else None)
    return r
