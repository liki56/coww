"""Sign-in, profile, doctors (admin only) and owners."""
import re
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from . import auth, db
from .auth import current_user, require

router = APIRouter(prefix="/api")
USER = re.compile(r"^[A-Za-z0-9_.-]{3,30}$")


def phone10(p, required=True):
    p = re.sub(r"[\s-]", "", p or ""); p = re.sub(r"^(\+?91)(?=\d{10}$)", "", p)
    if not p and not required: return ""
    if not re.fullmatch(r"\d{10}", p): raise HTTPException(422, "Enter a valid 10-digit phone number.")
    return p


def need(v, label):
    v = (v or "").strip()
    if not v: raise HTTPException(422, f"{label} is required.")
    return v


class Login(BaseModel): login: str; password: str
class PwChange(BaseModel): old_password: str; new_password: str
class DoctorIn(BaseModel): name: Optional[str] = None; phone: Optional[str] = None; area: Optional[str] = None; username: Optional[str] = None; password: Optional[str] = None
class OwnerIn(BaseModel): name: Optional[str] = None; phone: Optional[str] = None; address: Optional[str] = None; village: Optional[str] = None


def public(c): return dict(role=c["role"], name=c["name"], username=c["username"], ref_id=c["ref_id"], phone=c["phone"], area=c["area"])


@router.post("/auth/login")
def login(b: Login):
    key = b.login.strip().lower(); auth.throttle_check(key)
    u = db.get_user(b.login); ctx = db.user_ctx(u["_id"]) if u else None
    if not ctx or not auth.check_pw(b.password, u["pw_hash"]):
        auth.throttle_fail(key); raise HTTPException(401, "Wrong ID or password.")
    auth.throttle_ok(key)
    return dict(token=auth.make_token(u["_id"], u["role"]), user=public(ctx))


@router.get("/me")
def me(u=Depends(current_user)): return public(u)


@router.post("/me/password")
def change_pw(b: PwChange, u=Depends(current_user)):
    if not auth.check_pw(b.old_password, db.get_user(u["id"])["pw_hash"]): raise HTTPException(400, "Current password is wrong.")
    if len(b.new_password) < 6: raise HTTPException(422, "New password must be at least 6 characters.")
    db.set_password(u["id"], auth.hash_pw(b.new_password)); return dict(ok=True)


# ---------------- doctors (admin) ----------------
def _doctor(did):
    d = db.get_doctor(did)
    if not d: raise HTTPException(404, "Doctor not found.")
    return d


@router.get("/doctors")
def doctors(q: str = "", u=Depends(require("ADMIN"))): return db.doctors(q)


@router.post("/doctors")
def doctor_create(b: DoctorIn, u=Depends(require("ADMIN"))):
    name, area, phone = need(b.name, "Name"), need(b.area, "Assigned area / villages"), phone10(b.phone)
    login_id = (b.username or "").strip()
    if login_id and not USER.match(login_id): raise HTTPException(422, "Login ID must be 3-30 letters, digits or . _ -")
    if not login_id:
        base = "dr." + re.sub(r"[^a-z0-9]", "", name.lower().split()[0])
        login_id, n = base, 1
        while db.get_user(login_id): n += 1; login_id = f"{base}{n}"
    elif db.get_user(login_id): raise HTTPException(409, "That login ID is already taken.")
    pw = (b.password or "").strip() or auth.gen_pw()
    if len(pw) < 6: raise HTTPException(422, "Password must be at least 6 characters.")
    did = db.add_doctor(dict(name=name, phone=phone, area=area, username=login_id), u["username"])
    db.create_user(login_id, auth.hash_pw(pw), "DOCTOR", ref_id=did, name=name)
    return dict(ok=True, id=did, credentials=dict(user_id=login_id, password=pw, note="Share these with the doctor now. The password cannot be shown again."))


@router.get("/doctors/{did}")
def doctor_get(did: str, u=Depends(require("ADMIN"))):
    d = _doctor(did); d["cows"] = db.list_cows(registered_by=did, limit=100); return d


@router.put("/doctors/{did}")
def doctor_edit(did: str, b: DoctorIn, u=Depends(require("ADMIN"))):
    _doctor(did); d = {}
    if b.name is not None: d["name"] = need(b.name, "Name")
    if b.phone is not None: d["phone"] = phone10(b.phone)
    if b.area is not None: d["area"] = need(b.area, "Assigned area / villages")
    db.update_doctor(did, d); return db.get_doctor(did)


@router.delete("/doctors/{did}")
def doctor_delete(did: str, permanent: bool = False, u=Depends(require("ADMIN"))):
    d = _doctor(did)
    if permanent:
        if d["cows_registered"]: raise HTTPException(409, "This doctor has registered cows. Deactivate instead.")
        db.delete_doctor(did)
    else: db.set_doctor_active(did, False)
    return dict(ok=True)


@router.post("/doctors/{did}/activate")
def doctor_activate(did: str, u=Depends(require("ADMIN"))): _doctor(did); db.set_doctor_active(did, True); return dict(ok=True)


@router.post("/doctors/{did}/reset-password")
def doctor_reset(did: str, u=Depends(require("ADMIN"))):
    d = _doctor(did); pw = auth.gen_pw(); db.set_password(d["username"].lower(), auth.hash_pw(pw))
    return dict(ok=True, credentials=dict(user_id=d["username"], password=pw, note="Temporary password. Share it now."))


# ---------------- owners ----------------
def _owner(oid):
    o = db.get_owner((oid or "").strip().upper())
    if not o: raise HTTPException(404, "Owner ID not found.")
    return o


@router.get("/owners")
def owners(q: str = "", u=Depends(require("ADMIN", "DOCTOR"))): return db.owners(q)


@router.get("/owners/{oid}")
def owner_get(oid: str, u=Depends(require("ADMIN", "DOCTOR"))):
    o = _owner(oid); o["cows"] = db.list_cows(owner_id=o["owner_id"]); return o


@router.post("/owners")
def owner_create(b: OwnerIn, u=Depends(require("ADMIN", "DOCTOR"))):
    oid = db.add_owner(dict(name=need(b.name, "Name"), phone=phone10(b.phone), address=need(b.address, "Address"), village=(b.village or "").strip()), u)
    return dict(ok=True, owner=db.get_owner(oid))


@router.put("/owners/{oid}")
def owner_edit(oid: str, b: OwnerIn, u=Depends(require("ADMIN", "DOCTOR"))):
    o = _owner(oid); d = {}
    if b.name is not None: d["name"] = need(b.name, "Name")
    if b.phone is not None: d["phone"] = phone10(b.phone)
    if b.address is not None: d["address"] = need(b.address, "Address")
    if b.village is not None: d["village"] = b.village.strip()
    db.update_owner(o["owner_id"], d); return db.get_owner(o["owner_id"])


@router.delete("/owners/{oid}")
def owner_delete(oid: str, u=Depends(require("ADMIN"))): o = _owner(oid); db.delete_owner(o["owner_id"]); return dict(ok=True)
