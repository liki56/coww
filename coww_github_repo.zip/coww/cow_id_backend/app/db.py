"""MongoDB layer. People, cows, muzzle samples and full cow images all live in MongoDB (nothing on disk).
Collections: users, doctors, owners, cows, cow_samples, settings.
The function names get_cow / add_cow / add_samples / samples / cow_ids_with_samples are what the unchanged ML engine calls."""
import re
from datetime import date, datetime, timedelta
import numpy as np
import pymongo
from bson import Binary
from . import config as C

_db = None
now = lambda: datetime.now().isoformat(timespec="seconds")
today = lambda: date.today().isoformat()


def conn():
    global _db
    if _db is None:
        _db = pymongo.MongoClient(C.MONGODB_URI, serverSelectionTimeoutMS=8000)[C.MONGODB_DB]
    return _db


def init():
    d = conn()
    try:
        d.command("ping")
    except Exception as e:
        raise RuntimeError("Cannot connect to MongoDB. Check MONGODB_URI in .env (for Atlas also Network Access). Details: " + str(e)[:200])
    d.cows.create_index("owner_id"); d.cows.create_index("registered_by"); d.cow_samples.create_index("cow_id")


def next_code(coll, prefix, width):
    last = conn()[coll].find_one({"_id": {"$regex": f"^{prefix}\\d{{{width}}}$"}}, sort=[("_id", -1)])
    return f"{prefix}{(int(last['_id'][len(prefix):]) + 1 if last else 1):0{width}d}"


def _rx(q): return re.compile(re.escape(q.strip()), re.I)
def get_setting(k): r = conn().settings.find_one({"_id": k}); return r["v"] if r else None
def set_setting(k, v): conn().settings.update_one({"_id": k}, {"$set": {"v": v}}, upsert=True)


# ---------------- users ----------------
def get_user(login): return conn().users.find_one({"_id": (login or "").strip().lower()})
def admin_exists(): return conn().users.find_one({"role": "ADMIN"}) is not None
def set_password(uid, h): conn().users.update_one({"_id": uid}, {"$set": {"pw_hash": h}})


def create_user(username, pw_hash, role, ref_id=None, name=""):
    conn().users.insert_one({"_id": username.strip().lower(), "username": username.strip(), "pw_hash": pw_hash, "role": role,
                             "active": True, "ref_id": ref_id, "name": name, "created_at": now()})


def user_ctx(uid):
    u = conn().users.find_one({"_id": uid})
    if not u or not u.get("active"): return None
    ctx = dict(id=u["_id"], username=u["username"], role=u["role"], name=u.get("name") or u["username"], ref_id=u.get("ref_id"), phone="", area="")
    if u["role"] == "DOCTOR":
        d = conn().doctors.find_one({"_id": u["ref_id"]})
        if not d or not d.get("active"): return None
        ctx.update(name=d["name"], phone=d.get("phone", ""), area=d.get("area", ""))
    return ctx


# ---------------- doctors ----------------
def _out(d):
    if d: d.pop("_id", None)
    return d


def add_doctor(d, by):
    did = next_code("doctors", "VET", 3)
    conn().doctors.insert_one({"_id": did, "doctor_id": did, "name": d["name"], "phone": d["phone"], "area": d["area"], "username": d["username"],
                               "active": True, "created_by": by, "created_at": now()})
    return did


def get_doctor(did):
    d = conn().doctors.find_one({"_id": did})
    if d: d["cows_registered"] = conn().cows.count_documents({"registered_by": did})
    return _out(d)


def doctors(q=""):
    f = {"$or": [{k: _rx(q)} for k in ("name", "phone", "area", "username", "doctor_id")]} if q else {}
    n = {r["_id"]: r["n"] for r in conn().cows.aggregate([{"$group": {"_id": "$registered_by", "n": {"$sum": 1}}}])}
    rows = list(conn().doctors.find(f).sort("_id", 1))
    for r in rows: r["cows_registered"] = n.get(r["_id"], 0)
    return [_out(r) for r in rows]


def update_doctor(did, d):
    d = {k: v for k, v in d.items() if k in ("name", "phone", "area") and v is not None}
    if d: conn().doctors.update_one({"_id": did}, {"$set": d})
    if "name" in d: conn().users.update_many({"ref_id": did}, {"$set": {"name": d["name"]}})


def set_doctor_active(did, flag):
    conn().doctors.update_one({"_id": did}, {"$set": {"active": flag}}); conn().users.update_many({"ref_id": did}, {"$set": {"active": flag}})


def delete_doctor(did): conn().doctors.delete_one({"_id": did}); conn().users.delete_many({"ref_id": did})


# ---------------- owners ----------------
def add_owner(d, by):
    oid = next_code("owners", "OWN", 4)
    conn().owners.insert_one({"_id": oid, "owner_id": oid, "name": d["name"], "phone": d["phone"], "address": d.get("address", ""), "village": d.get("village", ""),
                              "created_by": by["ref_id"] or by["username"], "created_by_name": by["name"], "created_at": now()})
    return oid


def get_owner(oid):
    o = conn().owners.find_one({"_id": oid})
    if o: o["n_cows"] = conn().cows.count_documents({"owner_id": oid})
    return _out(o)


def owners(q=""):
    f = {"$or": [{k: _rx(q)} for k in ("name", "phone", "address", "village", "owner_id")]} if q else {}
    n = {r["_id"]: r["n"] for r in conn().cows.aggregate([{"$match": {"owner_id": {"$ne": None}}}, {"$group": {"_id": "$owner_id", "n": {"$sum": 1}}}])}
    rows = list(conn().owners.find(f).sort("_id", 1))
    for r in rows: r["n_cows"] = n.get(r["_id"], 0)
    return [_out(r) for r in rows]


def update_owner(oid, d):
    d = {k: v for k, v in d.items() if k in ("name", "phone", "address", "village") and v is not None}
    if d: conn().owners.update_one({"_id": oid}, {"$set": d})


def delete_owner(oid):
    conn().cows.update_many({"owner_id": oid}, {"$set": {"owner_id": None}}); conn().owners.delete_one({"_id": oid})


# ---------------- cows ----------------
def age_now(c):
    m = c.get("age_months")
    if m is None: return None
    try:
        d0, t = date.fromisoformat((c.get("age_set_on") or c.get("registered_at") or today())[:10]), date.today()
        m += max(0, (t.year - d0.year) * 12 + t.month - d0.month - (1 if t.day < d0.day else 0))
    except ValueError:
        pass
    return m


def age_text(m):
    if m is None: return ""
    y, mo = divmod(m, 12)
    return " ".join(p for p in (f"{y} yr" if y else "", f"{mo} mo" if mo else "") if p) or "newborn"


def _fin(c):
    m = age_now(c); c["age_now_months"] = m; c["age_text"] = age_text(m); return c


def get_cow(cow_id):
    c = conn().cows.find_one({"_id": cow_id}, {"full_image": 0})
    if not c: return None
    c.pop("_id"); c["n_photos"] = conn().cow_samples.count_documents({"cow_id": cow_id}); return _fin(c)


def list_cows(q="", owner_id=None, unowned=False, registered_by=None, limit=500):
    f = {}
    if owner_id: f["owner_id"] = owner_id
    if unowned: f["owner_id"] = None
    if registered_by: f["registered_by"] = registered_by
    if q:
        ids = [o["_id"] for o in conn().owners.find({"name": _rx(q)}, {"_id": 1})]
        f["$or"] = [{k: _rx(q)} for k in ("cow_id", "name", "breed", "color", "location")] + ([{"owner_id": {"$in": ids}}] if ids else [])
    rows = list(conn().cows.find(f, {"full_image": 0}).sort("registered_at", -1).limit(limit))
    names = {o["_id"]: o["name"] for o in conn().owners.find({"_id": {"$in": [r["owner_id"] for r in rows if r.get("owner_id")]}}, {"name": 1})}
    for r in rows: r.pop("_id"); r["owner_name"] = names.get(r.get("owner_id")); _fin(r)
    return rows


def add_cow(cow_id, d):
    conn().cows.insert_one({"_id": cow_id, "cow_id": cow_id, "name": d.get("name", ""), "breed": d.get("breed", ""), "sex": d.get("sex", ""),
                            "color": d.get("color", ""), "age_months": d.get("age_months"), "age_set_on": today(), "location": d.get("location", ""),
                            "notes": d.get("notes", ""), "owner_id": d.get("owner_id") or None, "registered_by": d.get("registered_by"),
                            "registered_by_name": d.get("registered_by_name", ""), "registered_at": d.get("registered_at") or now(), "has_image": False})


def update_cow(cow_id, d, by=None):
    d = {k: v for k, v in d.items() if k in ("name", "breed", "sex", "color", "location", "notes", "owner_id", "age_months") and v is not None}
    if "owner_id" in d: d["owner_id"] = d["owner_id"] or None
    if "age_months" in d: d["age_set_on"] = today()
    if d: conn().cows.update_one({"_id": cow_id}, {"$set": {**d, "updated_at": now(), "updated_by": by}})


def set_image(cow_id, jpeg): conn().cows.update_one({"_id": cow_id}, {"$set": {"full_image": Binary(jpeg), "has_image": True}})
def get_image(cow_id): c = conn().cows.find_one({"_id": cow_id}, {"full_image": 1}); return bytes(c["full_image"]) if c and c.get("full_image") else None
def delete_cow(cow_id): conn().cows.delete_one({"_id": cow_id}); conn().cow_samples.delete_many({"cow_id": cow_id})


# ---------------- muzzle samples (used by the ML engine) ----------------
def add_samples(cow_id, embs, pngs, sharps):
    conn().cow_samples.insert_many([{"cow_id": cow_id, "emb": Binary(np.asarray(e, np.float32).tobytes()), "gray": Binary(p), "sharp": float(s)}
                                    for e, p, s in zip(embs, pngs, sharps)])


def samples(cow_id):
    return [(str(r["_id"]), np.frombuffer(bytes(r["emb"]), np.float32), bytes(r["gray"])) for r in conn().cow_samples.find({"cow_id": cow_id}).sort("_id", 1)]


def cow_ids_with_samples(): return conn().cow_samples.distinct("cow_id")


# ---------------- dashboard ----------------
def stats(doctor_id=None):
    c, t = conn().cows, date.today()
    day = lambda n: (t - timedelta(days=n)).isoformat()
    out = dict(doctors=conn().doctors.count_documents({"active": True}), owners=conn().owners.count_documents({}), cows=c.count_documents({}),
               today=c.count_documents({"registered_at": {"$gte": day(0)}}), week=c.count_documents({"registered_at": {"$gte": day(6)}}),
               no_owner=c.count_documents({"owner_id": None}))
    if doctor_id: out["mine"] = c.count_documents({"registered_by": doctor_id}); out["mine_today"] = c.count_documents({"registered_by": doctor_id, "registered_at": {"$gte": day(0)}})
    out["recent"] = list_cows(registered_by=doctor_id, limit=6)
    return out
