"""Password hashing (scrypt), signed expiring tokens (HMAC-SHA256) and role checks. Standard library only."""
import base64, hashlib, hmac, json, secrets, time
from fastapi import Depends, Header, HTTPException
from . import config as C, db

_key = None


def _secret():
    global _key
    if _key is None:
        _key = (C.SECRET_KEY or db.get_setting("secret") or "").encode()
        if not _key:
            s = secrets.token_hex(32); db.set_setting("secret", s); _key = s.encode()
    return _key


def hash_pw(pw):
    salt = secrets.token_bytes(16)
    return f"scrypt${salt.hex()}${hashlib.scrypt(pw.encode(), salt=salt, n=2 ** 14, r=8, p=1).hex()}"


def check_pw(pw, stored):
    try:
        _, salt, h = stored.split("$")
        return hmac.compare_digest(hashlib.scrypt(pw.encode(), salt=bytes.fromhex(salt), n=2 ** 14, r=8, p=1).hex(), h)
    except Exception:
        return False


def gen_pw(): return secrets.token_urlsafe(6)


def make_token(uid, role):
    body = base64.urlsafe_b64encode(json.dumps({"uid": uid, "role": role, "exp": int(time.time()) + C.TOKEN_HOURS * 3600}).encode()).decode().rstrip("=")
    return f"{body}.{hmac.new(_secret(), body.encode(), hashlib.sha256).hexdigest()}"


def read_token(tok):
    try:
        body, sig = tok.split(".")
        if not hmac.compare_digest(sig, hmac.new(_secret(), body.encode(), hashlib.sha256).hexdigest()): return None
        p = json.loads(base64.urlsafe_b64decode(body + "=" * (-len(body) % 4)))
        return p if p["exp"] > time.time() else None
    except Exception:
        return None


_fails = {}   # login -> [count, locked_until]


def throttle_check(key):
    if _fails.get(key, [0, 0])[1] > time.time(): raise HTTPException(429, "Too many failed attempts. Try again in a few minutes.")


def throttle_fail(key):
    n = _fails.get(key, [0, 0])[0] + 1
    _fails[key] = [0, time.time() + 300] if n >= 5 else [n, 0]


def throttle_ok(key): _fails.pop(key, None)


def current_user(authorization: str = Header(None)):
    p = read_token((authorization or "").replace("Bearer ", "").strip())
    ctx = db.user_ctx(p["uid"]) if p else None
    if not ctx: raise HTTPException(401, "Please sign in again.")
    return ctx


def require(*roles):
    def dep(u=Depends(current_user)):
        if u["role"] not in roles: raise HTTPException(403, "You do not have access to this.")
        return u
    return dep


def seed_admin():
    if db.admin_exists(): return
    db.create_user(C.ADMIN_USERNAME, hash_pw(C.ADMIN_PASSWORD), "ADMIN", name="Administrator")
    print(f"Demo admin created: ID '{C.ADMIN_USERNAME}'  (change the password after first sign-in)")
