"""All settings. Put them in the .env file (or real environment variables)."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _load_env():
    """Tiny .env reader (no extra dependency). Real environment variables win over the file."""
    f = ROOT / ".env"
    if f.exists():
        for line in f.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


_load_env()

# ---- database: everything is stored in MongoDB, nothing on this computer ----
MONGODB_URI = os.environ.get("MONGODB_URI", "mongodb://localhost:27017")
MONGODB_DB = os.environ.get("MONGODB_DB", "smartvet")

# ---- your muzzle detector ----
DET_WEIGHTS = Path(os.environ.get("DET_WEIGHTS", ROOT / "models" / "muzzle_det_best.pt"))

# ---- accounts ----
SECRET_KEY = os.environ.get("SECRET_KEY", "")          # empty = a random key is created once and kept in MongoDB
TOKEN_HOURS = int(os.environ.get("TOKEN_HOURS", 24))
ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin")          # demo admin, created on first start
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "Admin@123")

# ---- identification (same values as before; unchanged) ----
IMG, CENTER, TOPK = 224, 0.6, 3
Q_MIN_CONF, Q_MIN_SIDE, Q_MAX_GLARE = 0.50, 200, 0.10
SHARP_THR = float(os.environ.get("SHARP_THR", 250))
SIFT_MATCH = int(os.environ.get("SIFT_MATCH", 8))
SIFT_POSSIBLE = int(os.environ.get("SIFT_POSSIBLE", 5))
EMBED_POSSIBLE = float(os.environ.get("EMBED_POSSIBLE", 0.92))
MIN_ENROLL, KEEP_PER_CALL, MAX_SAMPLES = 3, 8, 16
