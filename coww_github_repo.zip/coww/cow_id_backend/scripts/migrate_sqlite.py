"""One-time: copy cows from the OLD local database (data/cows.db) into MongoDB, then you can delete the data/ folder.
Run from cow_id_backend:   python -m scripts.migrate_sqlite data/cows.db"""
import sqlite3, sys
from datetime import date
from bson import Binary
from app import db

db.init(); src = sqlite3.connect(sys.argv[1] if len(sys.argv) > 1 else "data/cows.db"); src.row_factory = sqlite3.Row
for c in src.execute("SELECT * FROM cows"):
    if db.get_cow(c["cow_id"]): print(c["cow_id"], "already in MongoDB, skipped"); continue
    months = None
    try: b = date.fromisoformat(c["birth_date"]); t = date.today(); months = max(0, (t.year - b.year) * 12 + t.month - b.month)
    except Exception: pass
    db.add_cow(c["cow_id"], dict(name=c["name"], breed=c["breed"], sex=c["sex"], notes=c["notes"], age_months=months, registered_by="migrated",
                                 registered_by_name="Imported", registered_at=c["created_at"]))
    s = list(src.execute("SELECT emb, gray, sharp FROM samples WHERE cow_id=?", (c["cow_id"],)))
    db.conn().cow_samples.insert_many([{"cow_id": c["cow_id"], "emb": Binary(r["emb"]), "gray": Binary(r["gray"]), "sharp": r["sharp"]} for r in s])
    print(c["cow_id"], "->", len(s), "muzzle samples copied (no owner yet: set it in the app)")
